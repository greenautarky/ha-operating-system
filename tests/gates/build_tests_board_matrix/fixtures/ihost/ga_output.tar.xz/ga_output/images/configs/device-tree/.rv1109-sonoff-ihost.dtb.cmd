savedcmd_arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dtb := /build/ga_output/host/bin/ccache /usr/bin/gcc -O2 -isystem /build/ga_output/host/include -L/build/ga_output/host/lib -Wl,-rpath,/build/ga_output/host/lib -E -Wp,-MMD,arch/arm/boot/dts/rockchip/.rv1109-sonoff-ihost.dtb.d.pre.tmp -nostdinc -I ./scripts/dtc/include-prefixes -undef -D__DTS__ -x assembler-with-cpp -o arch/arm/boot/dts/rockchip/.rv1109-sonoff-ihost.dtb.dts.tmp arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dts ; ./scripts/dtc/dtc -o arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dtb -b 0 -iarch/arm/boot/dts/rockchip/ -i./scripts/dtc/include-prefixes -@ -Wno-unique_unit_address -Wno-unit_address_vs_reg -Wno-avoid_unnecessary_addr_size -Wno-alias_paths -Wno-graph_child_address -Wno-simple_bus_reg   -d arch/arm/boot/dts/rockchip/.rv1109-sonoff-ihost.dtb.d.dtc.tmp arch/arm/boot/dts/rockchip/.rv1109-sonoff-ihost.dtb.dts.tmp ; cat arch/arm/boot/dts/rockchip/.rv1109-sonoff-ihost.dtb.d.pre.tmp arch/arm/boot/dts/rockchip/.rv1109-sonoff-ihost.dtb.d.dtc.tmp > arch/arm/boot/dts/rockchip/.rv1109-sonoff-ihost.dtb.d 

source_arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dtb := arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dts

deps_arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dtb := \
  arch/arm/boot/dts/rockchip/rv1109.dtsi \
  arch/arm/boot/dts/rockchip/rv1126.dtsi \
  scripts/dtc/include-prefixes/dt-bindings/clock/rockchip,rv1126-cru.h \
  scripts/dtc/include-prefixes/dt-bindings/gpio/gpio.h \
  scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/arm-gic.h \
  scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/irq.h \
  scripts/dtc/include-prefixes/dt-bindings/pinctrl/rockchip.h \
  scripts/dtc/include-prefixes/dt-bindings/power/rockchip,rv1126-power.h \
  scripts/dtc/include-prefixes/dt-bindings/soc/rockchip,boot-mode.h \
  arch/arm/boot/dts/rockchip/rv1126-pinctrl.dtsi \
  scripts/dtc/include-prefixes/arm64/rockchip/rockchip-pinconf.dtsi \
  arch/arm/boot/dts/rockchip/rv1126-sonoff-ihost.dtsi \

arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dtb: $(deps_arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dtb)

$(deps_arch/arm/boot/dts/rockchip/rv1109-sonoff-ihost.dtb):
