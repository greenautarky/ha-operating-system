"""The first-boot onboarding wizard — page, step and completion views.

Onboarding views are unauthenticated (like stock HA onboarding) but gated
by the completion state — once onboarding is done, the endpoints return
403. The actual wizard HTML is built by the frontend build pipeline and
served as a static file by the component root (like onboarding.html).
Includes the admin bypass (``/admin``) and the QA reset endpoint.
"""

from __future__ import annotations

import asyncio
import base64
import importlib
import json
import logging
import subprocess
from datetime import UTC, datetime
from urllib.parse import urlencode

from aiohttp import web
from homeassistant.auth.const import GROUP_ID_USER
from homeassistant.auth.providers.homeassistant import InvalidAuth
from homeassistant.components import frontend
from homeassistant.components.http import HomeAssistantView
from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store

from .. import dashboards
from ..consent import async_record_consent
from ..console_as import record_account
from ..const import SITE_DEFAULT_LANGUAGE
from ..household.dashboards_admin import _reconcile_dashboard_visibility
from ..household.masters import _read_master_user_ids, _write_master_users
from ..household.sub_users import _async_create_linked_person
from ..locale_defaults import async_apply_resident_locale_defaults
from ..redirects import redirect_keeping_query
from ..store import _async_get_hass_provider, _get_state, _get_store
from .pin import _check_pin_verified, _pin_required

_LOGGER = logging.getLogger(__name__)


async def _async_account_state(hass: HomeAssistant, provider, username: str):
    """Where ``username`` stands, as ``(state, user, credentials)``.

    Asked BEFORE creating anything, and it has THREE answers, not two:

        absent    the provider does not know the name        -> create it
        linked    a user owns the credential                 -> adopt (password first)
        unlinked  the provider knows the name, nobody owns it -> heal (password first)

    ``unlinked`` is what a request dropped between ``async_add_auth`` and
    ``async_link_user`` leaves behind — a browser closed, a phone locked, a
    Wi-Fi hop while the step was running. Measured on a canary on 2026-09-24:
    this used to be answered as "no user", the create branch ran, the provider
    said ``username_already_exists``, the step answered 400 — and every retry
    with that address did the same. The resident could never finish onboarding
    with their own address.

    `async_get_or_create_credentials` would happily mint a credential object
    for a name the provider does not know, so existence is read from the
    provider's own user list first (see `_provider_has`).
    """
    if not await _provider_has(provider, username):
        return "absent", None, None
    creds = await provider.async_get_or_create_credentials({"username": username})
    user = await hass.auth.async_get_user_by_credentials(creds)
    return ("linked" if user is not None else "unlinked"), user, creds


async def _provider_has(provider, username: str) -> bool:
    """Does Home Assistant's own provider hold a credential for ``username``?

    Read from its user list, normalised exactly as the provider normalises, so
    two spellings of one address stay one account.

    NOT by calling the provider's login methods. The version this replaced
    called `provider.async_get_auth`, which HassAuthProvider does not have: the
    AttributeError was swallowed by a bare `except` and read as "the user
    exists", on every call, since the day it was written. And `validate_login`
    cannot answer either — it raises the same InvalidAuth for an unknown user
    and a wrong password, on purpose (timing safety).
    """
    if provider.data is None:
        await provider.async_initialize()
    wanted = provider.data.normalize_username(username)
    return any(
        provider.data.normalize_username(u["username"]) == wanted
        for u in provider.data.users
    )


async def _async_create_account(hass: HomeAssistant, provider, name: str,
                                username: str, password: str):
    """Create the user, its credential and the link between them — all or nothing.

    Run under ``asyncio.shield`` by the caller: a client that disconnects
    cancels the REQUEST, and a request cancelled between the credential and the
    link is exactly how the ``unlinked`` state above was reached. Shielded, the
    three steps finish together even when nobody is listening any more; the
    next attempt then finds a ``linked`` account and adopts it.

    If a step fails for a real reason, BOTH halves are undone — the user and the
    provider's credential. Undoing only the user is what left a name the
    provider refused to create again.
    """
    user = await hass.auth.async_create_user(name, group_ids=[GROUP_ID_USER])
    try:
        await provider.async_add_auth(username, password)
    except Exception:
        await _async_undo(hass, provider, user, None)
        raise
    try:
        credentials = await provider.async_get_or_create_credentials({"username": username})
        await hass.auth.async_link_user(user, credentials)
    except Exception:
        await _async_undo(hass, provider, user, username)
        raise
    return user, credentials


async def _async_orphan_named(hass: HomeAssistant, name: str):
    """A user called ``name`` that no credential can log into, or None.

    Only ever a leftover: no credential, not generated by the system, not the
    owner. Anyone who could sign in has at least one credential.
    """
    for u in await hass.auth.async_get_users():
        if u.name == name and not u.credentials and not u.system_generated and not u.is_owner:
            return u
    return None


async def _async_undo(hass: HomeAssistant, provider, user, username: str | None) -> None:
    """Best-effort removal of what `_async_create_account` managed to create."""
    if username is not None:
        try:
            await provider.async_remove_auth(username)
        except Exception:
            _LOGGER.exception("onboarding: could not remove the credential for %s", username)
    try:
        await hass.auth.async_remove_user(user)
    except Exception:
        _LOGGER.exception("onboarding: could not remove the half-created user %s", user.id)

def _check_account_exists(hass: HomeAssistant) -> web.Response | None:
    """Return a 409 if no resident account has been created yet.

    ``complete`` is a one-way door: it sets ``completed: true``, and every
    other wizard step is then refused by :func:`_check_not_completed` — most
    importantly ``create_user``. So a flow that reaches ``complete`` without an
    account leaves a device that counts as onboarded and has nobody who can log
    in, and the only ways back are an admin token or a reflash.

    That is not hypothetical: on 2026-09-22 a ``create_user`` call was rejected
    for a missing ``client_id``, the flow carried on to ``complete``, and the
    device ended the wizard with one admin (created by converge) and no
    resident. The PIN gate added in 2.9.1 does not catch this — the caller had
    the PIN. The missing guard is ORDER, not authentication.

    The subject is the STATE the account step records, not a user count: a
    device always has the converge-created admin, so counting users would pass
    on exactly the broken device.
    """
    state = _get_state(hass)
    if "account" not in state.get("steps_done", []):
        return web.json_response(
            {
                "message": (
                    "No resident account on this device yet — complete the "
                    "account step first. Finishing here would close the wizard "
                    "with nobody able to log in."
                )
            },
            status=409,
        )
    return None


def _check_not_completed(hass: HomeAssistant) -> web.Response | None:
    """Return a 403 response if onboarding is already completed."""
    state = _get_state(hass)
    if state.get("completed"):
        return web.json_response(
            {"message": "Onboarding already completed"}, status=403
        )
    return None


class GAOnboardingPageView(HomeAssistantView):
    """Redirect to the built greenautarky-setup.html page.

    The actual HTML is built by the frontend build pipeline and served as a
    static file by the frontend component (just like onboarding.html).
    """

    url = "/greenautarky-setup"
    name = "greenautarky_site:page"
    requires_auth = False

    async def get(self, request: web.Request) -> web.Response:
        """Redirect to the built frontend page."""
        hass: HomeAssistant = request.app["hass"]
        state = _get_state(hass)
        # Both targets keep the caller's query: the device label's QR code
        # carries ?pin=&device=, and this route is one of the two the sweep of
        # 2026-09-22 found still dropping it (see redirects.py).
        if state.get("completed"):
            raise redirect_keeping_query(request, "/")
        raise redirect_keeping_query(request, "/greenautarky-setup.html")


class GAAdminBypassView(HomeAssistantView):
    """Admin shortcut that bypasses the GA tenant onboarding wizard.

    GET /admin redirects to /auth/authorize with self-referential OAuth
    params and ga_bypass=1, landing the admin on the normal HA login page
    (not the tenant onboarding wizard) regardless of onboarding state.

    Self-referential OAuth params (client_id = device origin, redirect_uri =
    device-origin/config) are required because <ha-authorize> rejects the
    request as "Invalid redirect URI" otherwise. /config is used instead
    of /lovelace so a logged-in admin lands in HA Settings — never on the
    GA setup panel which is the auto-default while onboarding is incomplete.

    A `ga_bypass=1` cookie is also set on the redirect response so the
    server-side IndexView (frontend/__init__.py) skips its own redirect
    when the post-OAuth `/config?code=…` landing arrives without the
    `ga_bypass=1` query (HA's OAuth strips query params from redirect_uri).
    """

    url = "/admin"
    name = "greenautarky_site:admin"
    requires_auth = False

    async def get(self, request: web.Request) -> web.Response:
        """Redirect to /auth/authorize with admin-bypass params."""
        # Build origin from the request so it works regardless of how the
        # device is reached (NetBird IP, LAN IP, hostname, public domain).
        origin = f"{request.scheme}://{request.host}"
        # `auth_callback=1` is required so the HA frontend SPA recognises
        # `/config?code=…&auth_callback=1` as its own OAuth callback and
        # exchanges the code for a token. Without it the SPA discards the
        # code and starts a fresh OAuth round-trip, forcing a second login.
        #
        # `state` mirrors what home-assistant-js-websocket does on its own
        # OAuth init: base64(JSON({hassUrl, clientId})). Without it the SPA
        # crashes with "InvalidCharacterError: atob" while validating the
        # callback. Bytes-form base64 to match what HA produces (no padding
        # is fine — HA decodes via atob which is permissive).
        state = base64.b64encode(
            json.dumps({"hassUrl": origin, "clientId": f"{origin}/"}).encode()
        ).decode()
        params = urlencode(
            {
                "client_id": f"{origin}/",
                "redirect_uri": f"{origin}/config?auth_callback=1",
                "state": state,
                "ga_bypass": "1",
            }
        )
        response = web.Response(
            status=302,
            headers={"location": f"/auth/authorize?{params}"},
        )
        # Mirror IndexView's cookie shape (frontend/__init__.py:735-743).
        response.set_cookie(
            "ga_bypass",
            "1",
            max_age=3600,
            httponly=True,
            samesite="Lax",
            path="/",
        )
        return response


class GAOnboardingStatusView(HomeAssistantView):
    """Return current onboarding status."""

    url = "/api/greenautarky_site/status"
    name = "api:greenautarky_site:status"
    requires_auth = False

    async def get(self, request: web.Request) -> web.Response:
        """Return onboarding status including PIN verification state."""
        hass: HomeAssistant = request.app["hass"]
        state = _get_state(hass)
        response = {**state}

        # Admin bypass cookie: report completed=true so authorize.ts (client-side)
        # skips the GA onboarding redirect and shows the normal HA login.
        if request.cookies.get("ga_bypass") == "1":
            response["completed"] = True

        # Add PIN status fields
        # The PIN step is always required: a device without a PIN file is not
        # provisioned, and the gate refuses it (fail closed, 2.12.8). Reporting
        # pin_required=False there made the wizard skip the PIN page and hit the
        # refusal one step later with nothing to enter.
        response["pin_required"] = True
        response["pin_provisioned"] = _pin_required(hass)
        response["pin_verified"] = state.get("pin_verified", False)
        locked_until = state.get("pin_locked_until")
        if locked_until:
            remaining = (
                datetime.fromisoformat(locked_until) - datetime.now(UTC)
            ).total_seconds()
            response["pin_retry_after"] = max(0, int(remaining))

        return self.json(response)


class GAOnboardingGDPRView(HomeAssistantView):
    """Handle GDPR consent."""

    url = "/api/greenautarky_site/gdpr"
    name = "api:greenautarky_site:gdpr"
    requires_auth = False

    async def post(self, request: web.Request) -> web.Response:
        """Accept GDPR consent."""
        hass: HomeAssistant = request.app["hass"]
        if err := _check_not_completed(hass):
            return err
        if err := _check_pin_verified(hass):
            return err

        state = _get_state(hass)
        store = _get_store(hass)

        body = await request.json()
        state["gdpr_accepted"] = bool(body.get("accepted", False))
        if "gdpr" not in state["steps_done"]:
            state["steps_done"].append("gdpr")
        await store.async_save(state)

        return self.json({"status": "ok"})


class GALedConfigView(HomeAssistantView):
    """Read/set the iHost status-LED on/off preference.

    The status LED is driven at runtime by ga_manager (Yellow=starting,
    Green=connected, Breathing Red=error). A customer can turn it off;
    this view persists ``led_disabled`` into the onboarding HA Store and
    ga_manager reads it from
    ``/homeassistant/.storage/greenautarky_site`` to decide whether
    to drive the ring or set it Off.

    Settable any time post-install (no onboarding-completion guard), so
    no ``_check_not_completed`` / ``_check_pin_verified`` gating here.
    """

    url = "/api/greenautarky_site/led"
    name = "api:greenautarky_site:led"
    requires_auth = False

    async def get(self, request: web.Request) -> web.Response:
        """Return the current LED on/off preference."""
        hass: HomeAssistant = request.app["hass"]
        state = _get_state(hass)
        return self.json({"led_disabled": bool(state.get("led_disabled", False))})

    async def post(self, request: web.Request) -> web.Response:
        """Set the LED on/off preference."""
        hass: HomeAssistant = request.app["hass"]
        state = _get_state(hass)
        store = _get_store(hass)

        body = await request.json()
        state["led_disabled"] = bool(body.get("led_disabled", False))
        state["led_modified"] = datetime.now(UTC).isoformat()
        state["led_modified_by"] = "gaci"
        await store.async_save(state)

        return self.json({"status": "ok", "led_disabled": state["led_disabled"]})


def _telemetry_set_preferences():
    """The telemetry component's consent entry point, or None if it is older.

    Resolved at call time, not import time: the two components load in no fixed
    order, and on a device the module lives under ``custom_components``.
    """
    for name in ("custom_components.greenautarky_telemetry", "greenautarky_telemetry"):
        try:
            module = importlib.import_module(name)
        except ImportError:
            continue
        setter = getattr(module, "async_set_preferences", None)
        if setter is not None:
            return setter
    return None


class GAOnboardingTelemetryView(HomeAssistantView):
    """Handle telemetry preferences."""

    url = "/api/greenautarky_site/telemetry"
    name = "api:greenautarky_site:telemetry"
    requires_auth = False

    async def post(self, request: web.Request) -> web.Response:
        """Save telemetry preferences."""
        hass: HomeAssistant = request.app["hass"]
        if err := _check_not_completed(hass):
            return err
        if err := _check_pin_verified(hass):
            return err

        state = _get_state(hass)
        store = _get_store(hass)

        body = await request.json()

        # Forward to greenautarky_telemetry — as a DECISION, through its entry
        # point. This used to write `error_logs` / `metrics` as flat keys into
        # the component's preferences dict and save that. A v2 record keeps
        # the truth in `tiers.<tier>.value`, which the flat write never
        # touched, and the OS gate reads the tiers: a resident who said yes to
        # Tier 2 was stored as `tier2: false` (bench device, 2026-09-16; Tier 1
        # looked right only because its default is True).
        telemetry_data = hass.data.get("greenautarky_telemetry")
        if telemetry_data:
            error_logs = bool(body.get("error_logs", False))
            metrics = bool(body.get("metrics", False))
            setter = _telemetry_set_preferences()
            if setter is not None:
                await setter(hass, error_logs=error_logs, metrics=metrics)
            else:
                # Older telemetry component (< 0.2.4). Keep the legacy write so
                # the wizard finishes — and say what it cannot record. A silent
                # fallback here is the same defect under another name.
                _LOGGER.warning(
                    "telemetry step: greenautarky_telemetry has no "
                    "async_set_preferences (component older than 0.2.4) — writing "
                    "the legacy flat keys only; the tier record stays at its defaults"
                )
                prefs = telemetry_data["preferences"]
                prefs["error_logs"] = error_logs
                prefs["metrics"] = metrics
                telemetry_store: Store = telemetry_data["store"]
                await telemetry_store.async_save(prefs)

        if "telemetry" not in state["steps_done"]:
            state["steps_done"].append("telemetry")
        await store.async_save(state)

        return self.json({"status": "ok"})


class GAOnboardingEthernetView(HomeAssistantView):
    """Handle Ethernet consent.

    Ethernet is disabled by default (set during provisioning by ga-flasher).
    Users must actively consent to enable it during onboarding.
    """

    url = "/api/greenautarky_site/ethernet"
    name = "api:greenautarky_site:ethernet"
    requires_auth = False

    async def post(self, request: web.Request) -> web.Response:
        """Save Ethernet preference and record consent."""
        hass: HomeAssistant = request.app["hass"]
        if err := _check_not_completed(hass):
            return err
        if err := _check_pin_verified(hass):
            return err

        state = _get_state(hass)
        store = _get_store(hass)

        body = await request.json()
        enable_ethernet = bool(body.get("enable_ethernet", False))

        # Record consent via the version-tracked consent system, WITH the
        # choice: until 2.12.3 "on" and "off" left the same record.
        await async_record_consent(
            hass, store, state, "ethernet", value=enable_ethernet
        )

        if enable_ethernet:

            def _enable_ethernet() -> None:
                subprocess.run(
                    ["ga-manage-ethernet", "enable"],
                    timeout=10,
                    check=False,
                )

            try:
                await hass.async_add_executor_job(_enable_ethernet)
            except Exception:
                _LOGGER.exception("Failed to enable Ethernet")
                return web.json_response(
                    {"message": "Failed to enable Ethernet"}, status=500
                )

        if "ethernet" not in state["steps_done"]:
            state["steps_done"].append("ethernet")
        await store.async_save(state)

        return self.json({"status": "ok"})


class GAOnboardingCompleteView(HomeAssistantView):
    """Mark onboarding as complete."""

    url = "/api/greenautarky_site/complete"
    name = "api:greenautarky_site:complete"
    requires_auth = False

    async def post(self, request: web.Request) -> web.Response:
        """Complete the GA onboarding."""
        hass: HomeAssistant = request.app["hass"]
        if err := _check_not_completed(hass):
            return err
        # Behind the PIN like the account step, and for the same reason. Until
        # 2.9.1 this step took an empty, unauthenticated POST and set
        # ``completed: true`` — the wizard vanished from a device that had no
        # resident account yet, and only an admin token could bring it back
        # (measured on a bench device, 2026-09-16). Telemetry and Ethernet got
        # the same gate: they record consents, and a consent nobody proved
        # physical access for is not one.
        if err := _check_pin_verified(hass):
            return err
        # The PIN says someone stood at the device. It does not say the wizard
        # was walked. See _check_account_exists.
        if err := _check_account_exists(hass):
            return err

        state = _get_state(hass)
        store = _get_store(hass)

        if "complete" not in state["steps_done"]:
            state["steps_done"].append("complete")
        state["completed"] = True
        await store.async_save(state)

        # Remove the sidebar panel (for app users)
        frontend.async_remove_panel(
            hass, "greenautarky-setup-panel", warn_if_unknown=False
        )

        _LOGGER.info("greenautarky onboarding completed")

        return self.json({"status": "ok", "redirect": "/"})


class GAOnboardingCreateUserView(HomeAssistantView):
    """Create a user account during greenautarky onboarding.

    This endpoint is unauthenticated (the end user has no account yet).
    It creates a normal (non-admin) user and returns an auth_code so the
    frontend can authenticate and continue with authenticated steps.
    """

    url = "/api/greenautarky_site/create_user"
    name = "api:greenautarky_site:create_user"
    requires_auth = False

    async def post(self, request: web.Request) -> web.Response:
        """Create a new user and return auth_code for frontend auth."""
        hass: HomeAssistant = request.app["hass"]
        if err := _check_not_completed(hass):
            return err
        if err := _check_pin_verified(hass):
            return err

        body = await request.json()
        client_id = body.get("client_id", "").strip()
        name = body.get("name", "").strip()
        # Home Assistant's auth provider normalises a username with
        # `username.strip().casefold()` and REFUSES a credential whose username
        # is not already in that form (`InvalidUsername:
        # username_not_normalized`). `.strip()` alone covers the whitespace half
        # and not the case half, so every address carrying a capital letter —
        # the normal way a person writes their own e-mail — ended this step with
        # a generic "could not create the credential" and no hint about what to
        # change (#53, measured on a bench device 2026-09-15).
        #
        # The same normalisation is applied HERE so that what we store, what the
        # resident later types, and what the provider accepts are one spelling.
        # Deliberately only the USERNAME: `name` is a person's name, not an
        # identifier, and keeps its capitals.
        username = body.get("username", "").strip().casefold()
        password = body.get("password", "")
        # This used to read `language` and drop it on the floor, so every
        # device kept running on HA's built-in "en" no matter what the wizard
        # sent. Server-side translations follow this field — that is how a
        # reset device ended up seeding rooms called "Living Room" (KB #169).
        # German is the product default; an explicit choice still wins.
        language = (body.get("language") or SITE_DEFAULT_LANGUAGE).strip()

        if not name or not username or not password or not client_id:
            return self.json_message(
                "client_id, name, username, and password are required",
                status_code=400,
            )

        # Create user in normal user group (not admin)
        provider = _async_get_hass_provider(hass)
        await provider.async_initialize()

        # THE ACCOUNT STEP IS NOT A DEAD END, AND IT DOES NOT LEAK USERS.
        #
        # This used to create the HA user FIRST and then add the credential. A
        # username that already existed raised InvalidUser, the handler
        # returned 400 — and the user it had just created stayed behind,
        # credential-less and invisible to the wizard. The panel offers no way
        # past this step, so the resident could only press the button again,
        # and every press left another orphan.
        #
        # Measured on a bench device 2026-08-27: FIVE attempts, THIRTEEN users
        # named "resident", exactly one of them able to log in. The device sat
        # at completed:false with "account" already in steps_done — set up, and
        # locked out. A dropped connection while submitting is enough to reach
        # that state.
        #
        # So: ask before creating, and if the credential already belongs to
        # someone, ADOPT that user instead of failing. Onboarding is a flow a
        # person walks once; it has to survive being walked twice.
        state, existing_user, credentials = await _async_account_state(hass, provider, username)
        if state != "absent":
            # Adopting an account — or healing a half-created one — means handing
            # out an auth_code for it, so the password has to be checked FIRST.
            # Without this, everyone who gets past the physical PIN could sign in
            # as an already-onboarded resident by typing their address — the
            # retry fix would have traded a dead end for a way in. The legitimate
            # case is someone re-submitting the form they just filled, so they
            # have the password; a mismatch is a wrong password, not a dead end,
            # and says so.
            try:
                await provider.async_validate_login(username, password)
            except InvalidAuth:
                _LOGGER.warning(
                    "onboarding: %s already exists (%s) and the password did not "
                    "match — refusing to adopt the account",
                    username, state,
                )
                return self.json_message(
                    "An account with this address already exists on this "
                    "device. Enter its password to continue.",
                    status_code=401,
                )
            if state == "linked":
                _LOGGER.info(
                    "onboarding: %s already exists and the password matched — "
                    "continuing with the existing account instead of failing the step",
                    username,
                )
                user = existing_user
            else:
                # A credential nobody owns: a request dropped between the
                # credential and the link. Give it the user it never got. NOT
                # `async_add_auth` again — the provider already has the name,
                # and asking for it twice is the 400 this branch replaces.
                _LOGGER.warning(
                    "onboarding: %s has a credential but no user (a dropped earlier "
                    "attempt) and the password matched — linking it now",
                    username,
                )
                # The dropped attempt also created the USER, before the credential.
                # Reuse it rather than make a second one — a user without any
                # credential cannot log in, so it is that attempt's leftover and
                # nobody else's. (Orphans are how thirteen "resident" users once
                # accumulated on one device.)
                user = await _async_orphan_named(hass, name) or await hass.auth.async_create_user(
                    name, group_ids=[GROUP_ID_USER]
                )
                await hass.auth.async_link_user(user, credentials)
        else:
            try:
                user, credentials = await asyncio.shield(
                    _async_create_account(hass, provider, name, username, password)
                )
            except asyncio.CancelledError:
                raise  # the shielded creation still finishes; a retry adopts it
            except Exception:
                _LOGGER.exception(
                    "onboarding: account creation failed for %s — both halves "
                    "removed so the step can be retried", username,
                )
                return self.json_message(
                    "Could not create the account credential", status_code=400
                )

        # Create a linked Person (guaranteed fleet-wide — ADR-0006).
        await _async_create_linked_person(hass, name, user.id)

        # A resident starts with a 24-hour clock and day-month-year dates —
        # never over a choice the user already made (an adopted account keeps
        # its own). Never raises. See locale_defaults.
        await async_apply_resident_locale_defaults(hass, user.id)

        # Persist the site language (.storage/core.config). Best-effort: a
        # failed language write must not cost the tenant their new account.
        if hass.config.language != language:
            try:
                await hass.config.async_update(language=language)
            except Exception:
                _LOGGER.exception("could not set site language to %s", language)

        # ADR-0006 hybrid main-user flag: the FIRST tenant user created during
        # device onboarding auto-becomes the main user (master) IF no main-user
        # flag exists yet. fleet-manager can override/revoke later (it rewrites
        # the same file). Best-effort — a failure here must not break onboarding.
        try:
            existing = await hass.async_add_executor_job(_read_master_user_ids, hass)
            if not existing:
                await hass.async_add_executor_job(
                    _write_master_users, hass, {user.id}
                )
                _LOGGER.info(
                    "onboarding: auto-flagged first tenant user %s as main user", user.id
                )
        except Exception as err:
            _LOGGER.warning("onboarding: could not auto-flag main user: %s", err)

        # Mark account step as done
        state = _get_state(hass)
        store = _get_store(hass)
        # Record WHICH account the onboarding created (or adopted): the console
        # login's "as resident" signs in as this account and nothing else.
        record_account(state, user.id)
        if "account" not in state.get("steps_done", []):
            state.setdefault("steps_done", []).append("account")

        # ADR-0006 matrix: every tenant user gets a personal dashboard,
        # assigned to them in the matrix. Best-effort (never raises); the
        # reconcile turns the assignment into native per-view visibility.
        personal_path = await dashboards.async_create_personal_dashboard(
            hass, state, user.id, name
        )
        await store.async_save(state)
        if personal_path:
            await _reconcile_dashboard_visibility(hass, personal_path, state)

        # Return auth_code so frontend can authenticate
        from homeassistant.components.auth import create_auth_code

        auth_code = create_auth_code(hass, client_id, credentials)

        _LOGGER.info("Created user via greenautarky onboarding: %s", name)

        return self.json({"auth_code": auth_code})


# ---------------------------------------------------------------------------
# Test/QA reset endpoint (admin-authenticated)
# ---------------------------------------------------------------------------


class GAOnboardingResetView(HomeAssistantView):
    """Reset GA onboarding state to allow re-running the wizard.

    Intended for QA and automated testing (e.g. ga-flasher stage 90).
    Requires admin authentication — the ga-flasher uses the admin token
    obtained during Phase 1 provisioning to call this endpoint.

    Resets: completed, gdpr_accepted, steps_done.
    Preserves: consents (version-tracked separately).
    """

    url = "/api/greenautarky_site/reset"
    name = "api:greenautarky_site:reset"
    requires_auth = True

    async def post(self, request: web.Request) -> web.Response:
        """Reset onboarding state."""
        hass: HomeAssistant = request.app["hass"]

        # Require admin
        user = request["hass_user"]
        if not user.is_admin:
            return web.json_response({"message": "Admin required"}, status=403)

        state = _get_state(hass)
        store = _get_store(hass)

        # Reset wizard state, preserve consents
        state["completed"] = False
        state["gdpr_accepted"] = False
        state["steps_done"] = []
        await store.async_save(state)

        # Re-register the sidebar panel if it was removed on completion.
        # Skip if already registered (e.g. onboarding was never completed).
        from homeassistant.components.frontend import DATA_PANELS

        # Relative import of our own package __init__ — works whether this
        # is loaded as a built-in (homeassistant.components.*) or a
        # custom_component (custom_components.*). Deferred (inside the
        # handler) to avoid a circular import: __init__.py imports this module.
        from .. import (
            PANEL_URL_PATH,
            _async_register_panel,
        )

        if PANEL_URL_PATH not in hass.data.get(DATA_PANELS, {}):
            await _async_register_panel(hass)

        _LOGGER.info("greenautarky onboarding state reset by %s", user.name)
        return self.json({"status": "ok"})
