"""What changed in a room, when, and WHY — the one thing history cannot say.

A card can already read `history/period` and see that a room's setpoint moved
from 21 to 23 at 14:32 (ga-frontend-bundle 1.22.0, `ga-heating-log-card`). What
it can never see is which of these it was:

    the resident pressed +           the weekly plan reached a slot
    a boost was asked for            a boost expired
    a window opened                  someone turned the dial ON THE RADIATOR
    a holiday started                a manual period ran out

They are the same two numbers in the recorder. Only this component knows the
difference, because it is the thing that decided — and it already models all of
it (`_overrides`, `manual_until`, `_check_hand_on_valve`, `_take_over_manually`).
This module is that knowledge written down at the moment it is still known,
rather than guessed afterwards from a pair of timestamps.

WHY A RING AND NOT A LOG FILE. A resident's question is "what happened to my
room", which is answered by the last handful of entries; nobody scrolls a
heating log. So each room keeps `MAX_PER_ROOM` entries and the oldest falls off.
That bound is the whole storage design: this dict is saved into
`.storage/ga_heating` next to the plan, and an unbounded list there would grow
without limit on a device nobody is watching, which is exactly how a 14 GB
`home-assistant.log` happened on another GA device in September.

WHY IT IS PUBLISHED ON THE ROOM ENTITY. The card then renders an attribute it
already has, with no second request and no recorder read on every room view. It
also means the entries survive exactly as long as the component says they do,
instead of as long as the recorder's retention happens to be.

PRIVACY. An entry carries no free text: a source is one of the fixed `SOURCE_*`
constants below, and that is still the only vocabulary a card has to translate.

IT DOES NAME THE ACCOUNT THAT ACTED, since 0.13.7. Until then it deliberately
did not, on the reasoning that there was no reason for an entry to name a
PERSON. The reason turned out to be the question the log is for: in a flat with
more than one account, "Benutzer hat auf 18 gestellt" cannot be told apart from
"somebody else did", and the resident reading it is the person most entitled to
know which. Asked for and decided on 2026-10-20, with the alternative on the
table of naming only GA staff.

What that means in practice, and what it deliberately does NOT mean:

  * The name is the Home Assistant account's display name, resolved HERE, at the
    moment of the change. No user id is stored and none is published — a card
    would need admin rights to resolve one, and an id in an attribute is a
    durable identifier where a display name is not.
  * `SOURCE_VALVE` never carries a name. A hand on the radiator has no account
    behind it, and inventing one would be the log's first lie.
  * Anything our own executor does — the plan, a window, an expiry, a balancing
    run — carries no name either. Those have a context of ours, not a person's.
  * Odoo #679 is the standing allowance for plain room names behind the
    authenticated on-device API; the account name rides on the same attribute,
    which never leaves the device except to someone already logged into it.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from homeassistant.core import Context, HomeAssistant
from homeassistant.util import dt as dt_util

#: Kept per room. Five is what the card shows; a few more so a resident can be
#: told "nothing since yesterday" without us having thrown yesterday away.
MAX_PER_ROOM = 20


async def acting_user(hass: HomeAssistant, context: Context | None) -> str | None:
    """The display name of the account behind ``context``, or None.

    None for everything that is not a person: our own executor's contexts carry
    no user, and neither does a radiator reporting its own state — which is
    exactly why `SOURCE_VALVE` needs no special case anywhere, it simply has
    nothing to resolve.

    Resolved at the moment of the change and stored as a NAME. Storing the id
    instead would put a durable identifier in a published attribute and leave
    the card unable to read it without admin rights; resolving later would also
    rename every past entry when somebody renames their account, which is not
    what a log says.
    """
    user_id = getattr(context, "user_id", None)
    if not user_id:
        return None
    user = await hass.auth.async_get_user(user_id)
    # A deleted account leaves entries that still carry the name it had.
    return (user.name or None) if user is not None else None

# ---------------------------------------------------------------------------
# The sources. A closed set on purpose: "why did my heating change" has a small
# number of true answers, and a free-text field would turn them into prose that
# no card can translate and no test can pin.
# ---------------------------------------------------------------------------

#: Someone used the card, the app or a voice assistant on the ROOM.
SOURCE_RESIDENT = "resident"
#: Someone turned the dial on the radiator itself (`_check_hand_on_valve`).
SOURCE_VALVE = "valve"
#: The weekly plan reached a slot.
SOURCE_PLAN = "plan"
#: A boost started.
SOURCE_BOOST = "boost"
#: A holiday / absence started or ended.
SOURCE_ABSENCE = "absence"
#: A window contact opened or closed.
SOURCE_WINDOW = "window"
#: A bounded change ran out and the room went back to the plan.
SOURCE_EXPIRY = "expiry"
#: A balancing run (ICHB) holds the room for its measurement hour.
SOURCE_BALANCING = "balancing"

SOURCES = (
    SOURCE_RESIDENT, SOURCE_VALVE, SOURCE_PLAN, SOURCE_BOOST,
    SOURCE_ABSENCE, SOURCE_WINDOW, SOURCE_EXPIRY, SOURCE_BALANCING,
)

KIND_MODE = "mode"
KIND_TARGET = "target"
#: SOMETHING HAPPENED, rather than a value changing. `to` carries what it was —
#: "ichb_started", "ichb_ended", "ichb_cancelled" — and `from` is None.
#:
#: A balancing run already shows up as the setpoints it writes, tagged
#: `balancing`, but "Soll 19 → 30" at noon and "30 → 19" an hour later only says
#: what happened to somebody who knows what a run is. A resident who was out
#: wants the two lines that name it (asked for 2026-10-08).
KIND_EVENT = "event"


def _log(hass: HomeAssistant) -> dict[str, list[dict[str, Any]]]:
    # Imported HERE, not at module level. `__init__` imports this module while it
    # is still executing — before it defines DOMAIN — so a top-level
    # `from . import DOMAIN` is a circular import that fails at load (CI, two
    # timezones, 2026-10-01). `calibration.py` gets away with the same line only
    # because climate.py pulls it in later, after the package has finished.
    from . import DOMAIN

    return hass.data[DOMAIN]["state"].setdefault("changes", {})


def record(
    hass: HomeAssistant,
    entity_id: str,
    kind: str,
    *,
    source: str,
    to: Any,
    frm: Any = None,
    when: datetime | None = None,
    by: str | None = None,
) -> dict[str, Any] | None:
    """Append one entry, or None when there was nothing to record.

    A write that changes nothing is NOT an entry. The executor re-asserts the
    plan's value at every slot and the fan-out writes the same setpoint to every
    valve of a room; logging those would fill the ring with "21 → 21" and push
    the one line a resident is looking for off the end within an hour.
    """
    if source not in SOURCES:
        raise ValueError(f"unknown change source {source!r}")
    if kind not in (KIND_MODE, KIND_TARGET, KIND_EVENT):
        raise ValueError(f"unknown change kind {kind!r}")
    if to is None or frm == to:
        return None

    # AN INSTANT, NOT A WALL CLOCK. A naive "14:32" is read by the card in the
    # BROWSER's zone, so anyone viewing from another zone saw every change
    # shifted. Stored with its offset it is one instant everywhere.
    # A naive `when` (the executor passes `datetime.now()`) is the process's
    # local clock: `.astimezone()` attaches THAT offset. `dt_util.as_local`
    # would assume UTC for a naive value and move the entry by the zone offset.
    if when is None:
        when = dt_util.now()
    elif when.tzinfo is None:
        when = when.astimezone()
    entry = {
        "at": when.isoformat(timespec="seconds"),
        "kind": kind,
        "from": frm,
        "to": to,
        "source": source,
    }
    # ABSENT, NOT NULL, when there is nobody to name. Every entry written before
    # 0.13.7 has no `by` at all, and a card that reads the key's ABSENCE as "no
    # account known" then treats old entries and a hand on the radiator the same
    # way, which is what they are. A `"by": null` would make the card's test for
    # it a test for two things.
    # STRIPPED, and whitespace is nobody. A Home Assistant account can be named
    # "   ", which is truthy here and would reach a card as a line with a
    # dangling separator and no name after it.
    name = str(by).strip() if by is not None else ""
    if name:
        entry["by"] = name
    room = _log(hass).setdefault(entity_id, [])
    room.append(entry)
    # Bounded in place: rebinding the list would leave the stored dict pointing
    # at the old one, and the cap would silently stop working.
    del room[:-MAX_PER_ROOM]

    # PERSISTED HERE, not by the caller. The ring lives in the same dict as the
    # plan, but nothing writes that dict to disk by itself — so an entry recorded
    # on a path that happens not to call `_save` afterwards survives only until
    # the next restart. Measured on 198.51.100.4 (2026-10-01): three dial turns
    # logged, HA restarted, all three gone, while the mode changes beside them
    # survived because `_take_over_manually` saves for its own reasons.
    #
    # A log that quietly loses entries is worse than no log: the gap is invisible,
    # and it is the OLD entries — the ones nobody can reconstruct — that go.
    from . import _save

    hass.async_create_task(_save(hass))
    return entry


def recent(hass: HomeAssistant, entity_id: str, count: int = 5) -> list[dict[str, Any]]:
    """The newest `count` entries, NEWEST FIRST — the order a card renders.

    Oldest-first is the order they are stored, because appending is how a ring
    works; reversing here means every consumer does not have to remember which
    end is which. Published as the room's `changes` attribute.
    """
    room = _log(hass).get(entity_id) or []
    return list(reversed(room[-count:]))


def forget(hass: HomeAssistant, entity_id: str) -> None:
    """Drop a room's entries — for a room that no longer exists.

    Without this, a flat that is re-paired keeps the previous tenant's changes in
    `.storage` for ever. It is two numbers and a source, not personal data, but
    it is also not THIS tenant's heating, and a log that outlives its subject is
    a thing nobody can explain when they find it.
    """
    _log(hass).pop(entity_id, None)
