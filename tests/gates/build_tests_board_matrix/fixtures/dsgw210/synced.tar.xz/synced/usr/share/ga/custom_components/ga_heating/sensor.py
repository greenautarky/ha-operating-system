"""Can anyone tell whether the heating is working?

Until this existed: no. The executor keeps a per-thermostat status in memory, readable
only by asking that one device over HTTP. A room that silently stops following its plan
was invisible to everyone — measured 2026-08-17, not one line from any GreenAutarky
in-Core component leaves the device: fluent-bit ships only the ga_manager container, and
the Home Assistant tail is commented out with its source file gone.

A health *entity* is the cheapest honest shape for this, because it rides a rail that
Home Assistant already has rather than a pipeline of ours.

⚠️ **An earlier version of this paragraph claimed that rail was already carrying data
on GA devices** — "Home Assistant state already flows to InfluxDB, it is how the
regulator reads room temperatures". That was read out of the regulator's queries and
never measured. It is false: measured on 2026-08-18, `ga_homeassistant_db` on a canary
held three `scheduler_*` measurements and no Home Assistant state at all, because no GA
device carried an `influxdb:` block. The rail has to be wired for this entity to be
fleet-visible; the entity is correct either way, but "somebody can see it" was an
assumption, not a fact.

What this deliberately is **not** is a log line. Logs are unbounded free text written by
whoever wrote the code, including every upstream integration; a diagnostic entity is a
declared shape we can point a dashboard or an alert at without shipping whatever someone
else decided to print. That distinction is the whole of the privacy design recorded in
Odoo #679.

It is also deliberately *coarse*, and it **names nothing**. A room name describes
someone's home: ``climate.schlafzimmer_papa`` in an always-on diagnostic is personal data
by any reading. Odoo #679 states the rule — counters without an entity reference need no
consent, entity references only pseudonymised and consent-gated, plain room names never —
and the first version of this file broke it three days after that rule was written.

So: state, counts, and a **stable pseudonym** per room. Stable matters, because "this
room has been failing for three days" must stay answerable without knowing which room.
The plain names, and the device's own words about a thermostat, stay behind the
authenticated on-device API (``GET /api/ga_heating/schedule`` returns ``status``), where
somebody with access and a reason can resolve a pseudonym.
"""

from __future__ import annotations

import hashlib
import logging
import secrets
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorStateClass,
)
from homeassistant.const import PERCENTAGE
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import EntityCategory

from . import DOMAIN, _overrides, _schedules, effective_target

_LOGGER = logging.getLogger(__name__)

STATE_OK = "ok"
STATE_DEGRADED = "degraded"
STATE_STALLED = "stalled"
STATE_UNKNOWN = "unknown"

# The executor ticks once a minute. Five gives a restart, a slow storage write and a
# clock nudge room to happen without crying wolf, and still notices within the same
# quarter-hour that the heating stopped being driven at all.
STALE_AFTER = timedelta(minutes=5)


class GAHeatingHealth(SensorEntity):
    """One entity for the whole component: is the heating doing what it was told?"""

    _attr_has_entity_name = False
    _attr_name = "GA heating health"
    _attr_unique_id = f"{DOMAIN}_health"
    _attr_icon = "mdi:heat-wave"
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass

    def _status(self) -> dict[str, Any]:
        return (self.hass.data.get(DOMAIN) or {}).get("status") or {}

    def _ref(self, entity_id: str) -> str:
        """A stable, per-device pseudonym for a room.

        Per-device salt, so the same room on two devices does not share a reference and
        nothing can be correlated across households. Kept in this component's storage —
        generated on first use, never logged.
        """
        state = (self.hass.data.get(DOMAIN) or {}).get("state") or {}
        salt = state.get("ref_salt")
        if not salt:
            salt = secrets.token_hex(16)
            state["ref_salt"] = salt
        return hashlib.sha256((salt + entity_id).encode()).hexdigest()[:12]

    @property
    def _not_following(self) -> list[str]:
        """Rooms whose thermostat is not doing what the plan says.

        `ok is False` is the executor's own verdict, and it is already careful about
        what counts: a resident on manual and a thermostat switched off are recorded as
        decisions with `ok=True`, not faults. Counting those here would make the signal
        fire constantly and teach everyone to ignore it — which is worse than not having
        it.
        """
        return sorted(e for e, s in self._status().items() if s.get("ok") is False)

    @property
    def _no_room_sensor(self) -> list[str]:
        """Rooms that have radiators but no thermometer of their own.

        A commissioning defect, not a heating fault, so it is kept apart from
        `native_value`: merging "the plan is not running" with "this room was built
        without a sensor" would make one number that answers neither question.
        """
        return sorted((self.hass.data.get(DOMAIN) or {}).get("no_room_sensor") or ())

    def _age(self, now: datetime) -> float | None:
        """Seconds since the executor last ran, or None if it never has."""
        last = (self.hass.data.get(DOMAIN) or {}).get("last_tick")
        return None if last is None else (now - last).total_seconds()

    def _value_at(self, now: datetime) -> str:
        """Split out from `native_value` so the clock is an argument in tests.

        A state that can only be reached by waiting five real minutes is a state nobody
        tests, and an untested branch in a health signal is worse than no signal.
        """
        age = self._age(now)
        # Never run is not stalled. A device that just booted has not stopped working,
        # and calling that a stall would fire on every restart until people stopped
        # looking — which is how a signal dies.
        if age is None:
            return STATE_UNKNOWN
        # Checked BEFORE anything else, because if nothing is running any more then the
        # rest of this entity is reporting the last good minute, however old that is.
        # That was the real hole: status is only ever written BY the executor, so a dead
        # executor leaves every reading frozen at "ok" forever.
        if age > STALE_AFTER.total_seconds():
            return STATE_STALLED
        # Nothing measured yet is NOT "ok". Reporting health over zero observations is
        # the failure this project keeps finding: a check that cannot go red.
        if not self._status():
            return STATE_UNKNOWN
        return STATE_DEGRADED if self._not_following else STATE_OK

    @property
    def native_value(self) -> str:
        return self._value_at(datetime.now())

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return self._attributes_at(datetime.now())

    def _attributes_at(self, now: datetime) -> dict[str, Any]:
        status = self._status()
        not_following = self._not_following

        overrides_active: dict[str, str] = {}
        for entity_id in _schedules(self.hass) | _overrides(self.hass).keys():
            effective = effective_target(
                _schedules(self.hass).get(entity_id) or {},
                _overrides(self.hass).get(entity_id),
                now,
            )
            if effective and not effective[0].startswith("slot:"):
                overrides_active[entity_id] = effective[0].split(":", 1)[0]

        return {
            # Pseudonyms, not names — see the module docstring. Still more useful than a
            # bare count: a stable reference makes "this same room again" answerable,
            # and somebody with access to the device can resolve it there.
            "rooms_not_following": [self._ref(e) for e in not_following],
            # The device's own words about a thermostat can carry a friendly name or a
            # serial. They stay on the authenticated API, not in an always-on attribute.
            # Coverage, not exit code: a monitor that inspected nothing has to say so
            # rather than look green.
            "rooms_observed": len(status),
            "rooms_with_a_plan": len(_schedules(self.hass)),
            # So nobody has to read storage to answer "why is it warm in there" — the
            # KIND of override, against a pseudonym, never the room.
            "overrides_active": {self._ref(e): kind for e, kind in overrides_active.items()},
            # Every room is meant to have a temperature sensor; one that has none falls
            # back to the radiator's own thermometer, which reads warmer than the room
            # once the radiator is hot. The person who can fix it gets the named report in
            # Settings → Repairs. This is the fleet-visible half: a count to alert on,
            # and a stable pseudonym so "still the same room?" stays answerable without
            # a room name ever leaving the house. Always present, so "none missing" and
            # "never looked" cannot be confused.
            "rooms_without_a_room_sensor": len(self._no_room_sensor),
            "rooms_without_a_room_sensor_refs": [self._ref(e) for e in self._no_room_sensor],
            # "Is the thing that measures still measuring?" — the one question every
            # other number here silently assumes the answer to. None means it has never
            # run, which is a different fact from "it ran and found nothing".
            "seconds_since_last_run": self._age(now),
            # AI mode (0.11.0): radiators in a room on AI that do NOT verifiably hold
            # the room's plan, and are therefore kept on `heat` and driven from here
            # instead of running it in their own `auto`. A count, never a name — the
            # room's own `valve_control` attribute says which and why, on the device.
            "valves_held_on_heat": self._valves_held_on_heat(),
        }

    def _valves_held_on_heat(self) -> int:
        from homeassistant.components.climate import HVACMode

        rooms = (self.hass.data.get(DOMAIN) or {}).get("room_entities") or {}
        held = 0
        for room in list(rooms.values()):
            if room.hvac_mode != HVACMode.AUTO:
                continue
            held += sum(1 for v in room.valve_control().values() if v != "auto")
        return held


class GAHouseHumidity(SensorEntity):
    """The mean of every room that HAS a hygrometer, as an entity that can be charted.

    WHY AN ENTITY AND NOT AN ATTRIBUTE. A room without a hygrometer has shown the
    house figure on its badge since 0.13.x — `current_humidity` falls back to
    `house_average_humidity` — so the number was never missing. The 24 h CHART was:
    `statistics-graph` draws long-term statistics, and an attribute has none, so a
    room with no hygrometer had a temperature curve (its valve measures one) and a
    blank where the humidity curve belongs. A TRV does not measure humidity, so
    there is no per-room fallback to reach for; the mean of the other rooms is the
    only honest answer ("in the rooms that dont have t&h sensor add a mean of other
    humidity similar to whats done for temperature", 2026-10-27).

    NOT diagnostic, unlike the health entity beside it: this one is for a resident
    to look at, and `EntityCategory.DIAGNOSTIC` would hide it from exactly the
    places that want to draw it.

    `state_class` is load-bearing rather than decoration — without it the recorder
    keeps no statistics and the chart stays empty while the badge works, which is
    the same trap the outdoor sensors documented.
    """

    _attr_has_entity_name = False
    _attr_name = "GA Luftfeuchtigkeit Haus"
    _attr_unique_id = f"{DOMAIN}_house_humidity"
    _attr_icon = "mdi:water-percent"
    _attr_device_class = SensorDeviceClass.HUMIDITY
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_native_unit_of_measurement = PERCENTAGE
    _attr_should_poll = True

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass

    @property
    def native_value(self) -> float | None:
        """None when no room has a hygrometer at all — an unavailable sensor, not a
        zero. A zero would be averaged into the statistics forever."""
        from .climate import house_average_humidity

        value = house_average_humidity(self.hass)
        return round(value, 1) if value is not None else None

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """How many rooms are behind the figure, so a reader can tell a house
        average from one room's hygrometer wearing a house's name."""
        rooms = (self.hass.data.get(DOMAIN) or {}).get("room_entities") or {}
        return {
            "rooms": sum(
                1 for r in rooms.values()
                if getattr(r, "room_sensor_humidity", None) is not None
            )
        }


async def async_setup_platform(
    hass: HomeAssistant,
    config: Any,
    async_add_entities: Any,
    discovery_info: Any = None,
) -> None:
    async_add_entities([GAHeatingHealth(hass), GAHouseHumidity(hass)])


# ── the one line that leaves the device ──────────────────────────────────────
#
# The health entity is honest and, until now, invisible: nothing off the device read
# it. The rail to fix that already exists and did not have to be built — ga_manager
# drops InfluxDB line protocol into `/share/telegraf/`, the host telegraf picks it up on
# a 60 s `inputs.file`, buffers it to disk and ships it to the central
# `device_metrics` store that Grafana already alarms on. Its own docstring says why a
# file and not an HTTP scrape: no port, no bearer token, no namespace plumbing.
#
# WHAT TRAVELS, and what deliberately does not. Odoo #679 states the rule: counters
# without an entity reference need no consent; entity references only pseudonymised and
# consent-gated; plain room names never. This emits **counts only**. The rail is in fact
# consent-gated already — `telegraf.service` carries
# `ConditionPathExists=/mnt/data/.ga-consent-metrics`, written by `ga-telemetry-gate`
# from the tier-2 consent store — so pseudonyms would be permissible here. They are left
# out anyway: the counts answer every question an alert can ask, and less data is less to
# defend. The pseudonyms stay in the entity, on the device, for whoever has access and a
# reason.
#
# No `device_id` field either: telegraf tags every metric with `uuid` and `device_label`
# globally, so adding one here would be the same identification twice.
TELEGRAF_DROP = Path("/share/telegraf/ga-heating.influx")

_STATE_NEVER_RAN = -1


def health_line_protocol(hass: HomeAssistant, now: datetime) -> str:
    """One InfluxDB line describing the heating's health. Counts only."""
    entity = GAHeatingHealth(hass)
    attrs = entity._attributes_at(now)
    age = attrs["seconds_since_last_run"]
    fields = {
        # Quoted: a string field in line protocol. The state is the headline an alert
        # matches on, and a number would need a legend nobody would keep in step.
        "state": f'"{entity._value_at(now)}"',
        # Always present. A missing field and a zero look identical on a dashboard, so
        # "never ran" is -1 — a value no real age can take.
        "seconds_since_last_run": f"{int(age) if age is not None else _STATE_NEVER_RAN}i",
        "rooms_observed": f"{attrs['rooms_observed']}i",
        "rooms_with_a_plan": f"{attrs['rooms_with_a_plan']}i",
        "rooms_not_following": f"{len(attrs['rooms_not_following'])}i",
        "rooms_without_a_room_sensor": f"{attrs['rooms_without_a_room_sensor']}i",
        "overrides_active": f"{len(attrs['overrides_active'])}i",
    }
    return "ga_heating " + ",".join(f"{k}={v}" for k, v in fields.items())


def write_health_drop(hass: HomeAssistant, now: datetime) -> None:
    """Write the line where telegraf will find it, atomically.

    Atomic because telegraf reads the whole file on its own 60 s schedule and the two
    are not coordinated: a half-written line is not valid line protocol, and telegraf
    drops what it cannot parse **silently** — which on a dashboard looks exactly like a
    healthy fleet.

    Failure here must never disturb the executor: the drop is a report about the
    heating, not part of heating.
    """
    try:
        TELEGRAF_DROP.parent.mkdir(parents=True, exist_ok=True)
        tmp = TELEGRAF_DROP.with_suffix(".tmp")
        tmp.write_text(health_line_protocol(hass, now) + "\n", encoding="utf-8")
        tmp.replace(TELEGRAF_DROP)
    except OSError as err:
        _LOGGER.debug("ga_heating: could not write %s (%r)", TELEGRAF_DROP, err)
