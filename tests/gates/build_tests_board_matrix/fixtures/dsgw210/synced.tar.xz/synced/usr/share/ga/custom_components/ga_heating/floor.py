"""Underfloor heating through a relay — the duty ladder, the PWM and the dead-man.

A room whose area holds a ``switch`` entity labelled ``ga_heat_actuator`` (a channel of
a Zigbee relay such as the GIRIER ZDS02 / Tuya TS0004) is an underfloor room. The room
entity stays the same ``GARoomClimate`` — plan, modes, overrides and the manual cap all
run through the executor exactly as for radiators — and this module turns the room's
target into a duty cycle and the duty cycle into relay writes. KB #323; the contract is
``docs/contracts/heating-decision-contract.md`` ("Reserved — desired_duty") in
ga-ihost-docs, and the rules quoted below come from it.

SOURCE ORDER per underfloor room, every minute:

  1. room ``off``                         → 0 %                    (``duty_source: off``)
  2. room sensor not usable               → fixed fallback duty    (``sensor_lost``)
     — option ``GA_HEATING_UFH_FALLBACK_DUTY``, 0…30 %, default 30, clamped; after 24 h
     in a row the room goes to 0 %. ``degraded`` with a repair issue from the start.
  3. a valid ``desired_duty`` from hmvapp → applied                (``hmvapp``)
     — only with option ``GA_HEATING_APPLY_DUTY`` on (default off).
  4. otherwise our own PID                → PID output 0…100 %     (``default``)
     — with the option on and no valid decision for > 10 min the room is ``degraded``.

Why 2 outranks 3: the engine computes its duty from the same room temperature that has
gone silent, so a "valid" decision in ``sensor_lost`` rests on stale input.

THE DEAD-MAN (normative). Every ON write re-arms the channel's own countdown
(``number.<ieee>_countdown_lN``) to the remaining planned ON time plus
``COUNTDOWN_MARGIN``, never more than the PWM period plus the margin. A channel whose
countdown entity cannot be found, or whose countdown write fails, is not switched ON —
and is switched OFF if it is ON. The relay runs with ``power_on_behavior: previous``,
so after a power cut it comes back ON; the countdown is the only thing that turns it
off when this component, Home Assistant or the iHost is gone.

⚠️ Order matters on this hardware: the Tuya countdown is a one-shot TOGGLE timer. Armed
on a channel that is OFF it would switch the channel ON when it runs out. So the
countdown is armed right AFTER the ON write, never before, and never on an OFF channel.
Measured on K0 on 2026-11-02 for a 60 s countdown on an ON channel only; longer
countdowns, and what an OFF command does to a running countdown, are not yet observed.

WRITES ONLY ON A DIFFERENCE. The relay's reported state is compared with what the PWM
wants; an equal state costs no radio traffic. A countdown is re-armed when it would run
out before the planned OFF — across a cycle boundary at 100 %, and after a restart,
when this module cannot know what was armed.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any

from homeassistant.components.climate import HVACMode
from homeassistant.core import HomeAssistant
from homeassistant.helpers import issue_registry as ir
from homeassistant.util import dt as dt_util

from . import DOMAIN, _own_context
from .floor_pid import PID

if TYPE_CHECKING:
    from .climate import GARoomClimate

_LOGGER = logging.getLogger(__name__)

#: The entity label that makes a switch a heating actuator. Set by the installer flow
#: (GACI → rooms sync); an unlabelled switch in a room is a lamp, never a floor.
ACTUATOR_LABEL = "ga_heat_actuator"

#: PWM period and the shortest ON / OFF slice. A floor is slow, a thermal actuator
#: takes minutes to open, and a relay is not a dimmer — 60 / 5 / 5 min (KB #323).
PWM_PERIOD = timedelta(minutes=60)
MIN_ON = timedelta(minutes=5)
MIN_OFF = timedelta(minutes=5)
COUNTDOWN_MARGIN = timedelta(minutes=5)

FALLBACK_OPTION = "GA_HEATING_UFH_FALLBACK_DUTY"
FALLBACK_DEFAULT = 30
FALLBACK_CAP = 30
#: After this long in `sensor_lost` the room stops heating on a guess.
SENSOR_LOST_LIMIT = timedelta(hours=24)

DUTY_OPTION = "GA_HEATING_APPLY_DUTY"
DUTY_SUFFIX = "_desired_duty"
REQUEST_PREFIX = "sensor.hm_"
#: Silence is LOUD for the duty, unlike the offset (contract).
ENGINE_SILENT_LOUD = timedelta(minutes=10)

#: A room in KI with no plan and no target has nothing to aim at. 20 °C is a
#: placeholder until a product decision says otherwise (KB #323 open points).
DEFAULT_TARGET = 20.0

#: PID tuning, PROVISIONAL — not measured on a real floor yet. Output in % of the
#: period: 1 K below target asks for 40 %, and an hour of that error adds another 40.
KP = 40.0
KI = 40.0 / 3600.0
KD = 0.0

_SWITCH_UID = re.compile(r"^(0x[0-9a-f]+)_switch_(l\d+)_zigbee2mqtt$", re.IGNORECASE)


def countdown_unique_id(switch_unique_id: str | None) -> str | None:
    """`0x…_switch_l1_zigbee2mqtt` → `0x…_countdown_l1_zigbee2mqtt` (Z2M, K0 2026-11-02)."""
    m = _SWITCH_UID.match(switch_unique_id or "")
    if m is None:
        return None
    return f"{m.group(1).lower()}_countdown_{m.group(2).lower()}_zigbee2mqtt"


def fallback_duty() -> int:
    raw = os.environ.get(FALLBACK_OPTION, "").strip()
    if not raw:
        return FALLBACK_DEFAULT
    try:
        value = int(float(raw))
    except ValueError:
        _LOGGER.warning("ga_heating: %s=%r is not a number — using %d %%",
                        FALLBACK_OPTION, raw, FALLBACK_DEFAULT)
        return FALLBACK_DEFAULT
    if value > FALLBACK_CAP or value < 0:
        clamped = max(0, min(FALLBACK_CAP, value))
        _LOGGER.warning("ga_heating: %s=%d is outside 0…%d — clamped to %d %%",
                        FALLBACK_OPTION, value, FALLBACK_CAP, clamped)
        return clamped
    return value


@dataclass
class Decision:
    duty: int
    source: str
    #: Every reason the room is degraded, in the order found. Empty = healthy. A
    #: list, not one string: a `sensor_lost` room that also loses its countdown has
    #: two problems, and reporting only the last one hides the first (review #72).
    degraded: list[str] = field(default_factory=list)

    def flag(self, reason: str) -> None:
        if reason not in self.degraded:
            self.degraded.append(reason)


def choose_duty(
    *,
    off: bool,
    sensor_ok: bool,
    lost_for: timedelta | None,
    engine_duty: int | None,
    engine_silent_for: timedelta | None,
    apply_engine: bool,
    pid_duty: int,
    fallback: int,
) -> Decision:
    """The contract's source order, as a pure function — see the module docstring."""
    if off:
        return Decision(0, "off")
    if not sensor_ok:
        if lost_for is not None and lost_for >= SENSOR_LOST_LIMIT:
            return Decision(0, "sensor_lost", ["sensor_lost_expired"])
        return Decision(fallback, "sensor_lost", ["sensor_lost"])
    if apply_engine and engine_duty is not None:
        return Decision(engine_duty, "hmvapp")
    decision = Decision(pid_duty, "default")
    if apply_engine and (engine_silent_for or timedelta(0)) > ENGINE_SILENT_LOUD:
        decision.flag("engine_silent")
    return decision


def on_time(duty: int) -> timedelta:
    """The ON slice of one period, with the minimum ON / OFF rules applied."""
    duty = max(0, min(100, int(duty)))
    slice_ = PWM_PERIOD * duty / 100
    if slice_ < MIN_ON:
        return timedelta(0)
    if PWM_PERIOD - slice_ < MIN_OFF:
        return PWM_PERIOD
    return slice_


def latch(latched: timedelta | None, duty: int) -> timedelta:
    """The ON slice IN FORCE for the running period (time-proportioning).

    Fixed when the period starts. A LOWER duty acts at once — toward safe, and an
    `off` or `sensor_lost_expired` must not wait up to an hour. A HIGHER duty waits for
    the next period. Without this the slice was recomputed every minute against a
    fixed period start, and a PID output wandering around the elapsed time flipped
    the relay every minute (reproduced in review #72: 29 → 36 → 30 → 38 → 31 %).
    """
    wanted = on_time(duty)
    return wanted if latched is None else min(latched, wanted)


def countdown_seconds(off_at: datetime, now: datetime) -> int:
    span = min(off_at - now + COUNTDOWN_MARGIN, PWM_PERIOD + COUNTDOWN_MARGIN)
    return max(int(span.total_seconds()), int(COUNTDOWN_MARGIN.total_seconds()))


@dataclass
class FloorState:
    """In memory per room. A restart starts a new period and re-arms every ON channel,
    which is the safe answer to "what did we arm before?"."""

    pid: PID = field(default_factory=lambda: PID(KP, KI, KD, out_min=0, out_max=100))
    cycle_start: datetime | None = None
    #: The ON slice in force for this period — see `latch`.
    latched: timedelta | None = None
    lost_since: datetime | None = None
    engine_invalid_since: datetime | None = None
    #: relay → until when its countdown runs, as armed by us.
    armed_until: dict[str, datetime] = field(default_factory=dict)
    #: relay → (seconds armed, when) — waiting for the device's echo.
    pending: dict[str, tuple[int, datetime]] = field(default_factory=dict)
    #: relay → kept OFF until then, because its dead-man could not be confirmed.
    blocked_until: dict[str, datetime] = field(default_factory=dict)
    decision: Decision | None = None


def _states(hass: HomeAssistant) -> dict[str, FloorState]:
    return hass.data.setdefault(DOMAIN, {}).setdefault("floor", {})


def _engine_duty(hass: HomeAssistant, room: GARoomClimate, now: datetime) -> int | None:
    """A VALID desired_duty for this room, or None. Valid = contract major 2, unexpired,
    an underfloor room (this one is), an integer 0…100 (contract)."""
    from .hmvapp import _valid

    for state in hass.states.async_all("sensor"):
        if not (state.entity_id.startswith(REQUEST_PREFIX)
                and state.entity_id.endswith(DUTY_SUFFIX)
                and state.attributes.get("room") == room.entity_id):
            continue
        if state.state in ("unavailable", "unknown", ""):
            continue
        if not _valid(hass, state.entity_id, state, now):
            continue
        try:
            value = float(state.state)
        except ValueError:
            continue
        if value != int(value) or not 0 <= value <= 100:
            continue
        return int(value)
    return None


def _issue(hass: HomeAssistant, room: GARoomClimate, reasons: list[str]) -> None:
    issue_id = f"floor_degraded_{room._area_id}"
    if not reasons:
        ir.async_delete_issue(hass, DOMAIN, issue_id)
        return
    ir.async_create_issue(
        hass, DOMAIN, issue_id,
        is_fixable=False,
        severity=ir.IssueSeverity.WARNING,
        translation_key="floor_degraded",
        translation_placeholders={"room": str(room.name), "reason": ", ".join(reasons)},
    )


def decide(hass: HomeAssistant, room: GARoomClimate, now: datetime) -> Decision:
    """One room's duty for this minute. `now` is timezone-aware UTC."""
    from .hmvapp import option_enabled

    st = _states(hass).setdefault(room.entity_id, FloorState())
    temp = room.room_sensor_temperature
    if temp is None:
        st.lost_since = st.lost_since or now
    else:
        st.lost_since = None

    apply_engine = option_enabled(DUTY_OPTION)
    engine = _engine_duty(hass, room, now) if apply_engine else None
    if engine is not None:
        st.engine_invalid_since = None
    elif st.engine_invalid_since is None:
        # Starts when the last valid decision stops being valid, or at consumer start.
        st.engine_invalid_since = now

    off = room.hvac_mode == HVACMode.OFF
    target = room.target_temperature
    if target is None:
        target = DEFAULT_TARGET
    pid_duty = 0
    if temp is not None and not off:
        out, _ = st.pid.calc(temp, float(target), input_time=now.timestamp())
        pid_duty = round(max(0.0, min(100.0, out)))

    decision = choose_duty(
        off=off,
        sensor_ok=temp is not None,
        lost_for=(now - st.lost_since) if st.lost_since else None,
        engine_duty=engine,
        engine_silent_for=(now - st.engine_invalid_since)
        if st.engine_invalid_since else None,
        apply_engine=apply_engine,
        pid_duty=pid_duty,
        fallback=fallback_duty(),
    )
    if decision.source != "default":
        # The PID is not in charge, so it must not wind up for a hand-over later:
        # it starts again from its proportional term when it takes over.
        st.pid.clear_samples()
    st.decision = decision
    return decision


async def _call(hass: HomeAssistant, domain: str, service: str, data: dict[str, Any]) -> None:
    await hass.services.async_call(domain, service, data, blocking=True,
                                   context=_own_context(hass))


async def _off(hass: HomeAssistant, relay: str, countdown: str | None) -> None:
    """Cancel the countdown, THEN switch off. The countdown is a toggle timer: left
    running on a channel we switch OFF it would switch the channel back ON when it runs
    out. Whether an OFF command already cancels it on this hardware is not observed
    yet (K0 test), so it is cancelled explicitly; a failed cancel does not stop the
    OFF. A cancel the device swallows is caught one tick later: a channel that is ON
    while the period wants it OFF is switched OFF again."""
    if countdown is not None:
        try:
            await _call(hass, "number", "set_value", {"entity_id": countdown, "value": 0})
        except Exception as err:
            _LOGGER.warning("ga_heating: %s: cancelling countdown %s failed (%r)",
                            relay, countdown, err)
    await _call(hass, "switch", "turn_off", {"entity_id": relay})


def _echoed(hass: HomeAssistant, countdown: str, seconds: int, armed_at: datetime) -> bool:
    """Did the device report the countdown we armed? `number.set_value` on an MQTT
    entity only PUBLISHES (HA mqtt/number.py) — it succeeds for an offline relay or a
    dropped frame alike. Only the device's own report proves the dead-man is armed."""
    state = hass.states.get(countdown)
    if state is None or state.state in ("unknown", "unavailable", ""):
        return False
    try:
        value = float(state.state)
    except ValueError:
        return False
    reported = getattr(state, "last_reported", None) or state.last_updated
    # Measured on K0 (2026-11-03): the echo of the armed value arrives in the same
    # second, and the device then reports the remaining time about once a minute
    # (1380 → 1320 …). So: anything above zero and not above what we armed, reported
    # after we armed it. The check runs on the NEXT tick, ~60 s after the arm.
    return 0 < value <= seconds and reported >= armed_at


async def _drive_relay(
    hass: HomeAssistant, st: FloorState, decision: Decision,
    relay: str, countdown: str | None, want_on: bool, off_at: datetime, now: datetime,
) -> None:
    state = hass.states.get(relay)
    if state is None or state.state in ("unavailable", "unknown"):
        decision.flag("relay_unavailable")
        st.armed_until.pop(relay, None)
        st.pending.pop(relay, None)
        return
    is_on = state.state == "on"

    # 1. The dead-man armed last tick must have been confirmed by now.
    pending = st.pending.pop(relay, None)
    if pending is not None and countdown is not None:
        seconds, armed_at = pending
        if not _echoed(hass, countdown, seconds, armed_at):
            _LOGGER.warning(
                "ga_heating: %s: the device never reported countdown %s = %d s armed at "
                "%s — switching off for the rest of the period",
                relay, countdown, seconds, armed_at.isoformat())
            st.armed_until.pop(relay, None)
            st.blocked_until[relay] = (st.cycle_start or now) + PWM_PERIOD
            decision.flag("countdown_unconfirmed")
            if is_on:
                await _off(hass, relay, countdown)
            return

    blocked = st.blocked_until.get(relay)
    if blocked is not None and now >= blocked:
        st.blocked_until.pop(relay, None)
        blocked = None
    if blocked is not None:
        decision.flag("countdown_unconfirmed")
        want_on = False

    if want_on and countdown is None:
        # No dead-man, no ON (contract).
        decision.flag("no_countdown")
        want_on = False
    if not want_on:
        if is_on:
            await _off(hass, relay, countdown)
        st.armed_until.pop(relay, None)
        return
    if not is_on:
        await _call(hass, "switch", "turn_on", {"entity_id": relay})
        st.armed_until.pop(relay, None)
    armed = st.armed_until.get(relay)
    if armed is not None and armed >= off_at:
        return  # its countdown already outlasts the planned ON
    seconds = countdown_seconds(off_at, now)
    try:
        await _call(hass, "number", "set_value", {"entity_id": countdown, "value": seconds})
    except Exception as err:
        # Refused on the HA side (e.g. above the entity's max) → must not stay ON.
        _LOGGER.warning("ga_heating: %s: countdown %s refused (%r) — switching off",
                        relay, countdown, err)
        await _off(hass, relay, countdown)
        st.armed_until.pop(relay, None)
        decision.flag("countdown_failed")
        return
    st.armed_until[relay] = now + timedelta(seconds=seconds)
    st.pending[relay] = (seconds, now)


async def drive(hass: HomeAssistant, room: GARoomClimate, now: datetime) -> Decision:
    """Decide, then make every relay channel of the room say it. Returns the decision
    (with `degraded` set if a channel could not be driven safely)."""
    decision = decide(hass, room, now)
    st = _states(hass)[room.entity_id]
    if st.cycle_start is None or now >= st.cycle_start + PWM_PERIOD:
        st.cycle_start = now
        st.latched = None
    st.latched = latch(st.latched, decision.duty)
    off_at = st.cycle_start + st.latched
    want_on = now < off_at

    for relay, countdown in room.relays.items():
        try:
            await _drive_relay(hass, st, decision, relay, countdown, want_on, off_at, now)
        except Exception as err:  # one channel must not stop the others
            _LOGGER.warning("ga_heating: floor %s channel %s failed: %r",
                            room.entity_id, relay, err)
            decision.flag("drive_failed")

    _issue(hass, room, decision.degraded)
    return decision


async def async_drive_floors(hass: HomeAssistant, now: datetime | None = None) -> int:
    """One pass from the minute tick over every room that has relays. Returns how many
    rooms were driven."""
    now = now if now is not None else dt_util.utcnow()
    if now.tzinfo is None:
        now = now.replace(tzinfo=dt_util.UTC)
    done = 0
    rooms: dict[str, GARoomClimate] = hass.data.get(DOMAIN, {}).get("room_entities") or {}
    for room in list(rooms.values()):
        if not room.relays:
            continue
        try:
            await drive(hass, room, now)
            done += 1
        except Exception as err:  # one room must not stop the others
            # A floor that is not being driven is as loud as a degraded one.
            _LOGGER.warning("ga_heating: floor %s failed: %r", room.entity_id, err)
            try:
                _issue(hass, room, ["drive_failed"])
            except Exception:
                _LOGGER.exception("ga_heating: floor %s: repair issue failed", room.entity_id)
        room.async_write_ha_state()
    return done
