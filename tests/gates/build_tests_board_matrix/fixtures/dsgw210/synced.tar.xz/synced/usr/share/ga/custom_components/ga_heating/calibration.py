"""Valve calibration — teach each radiator valve what the room actually measures.

A TRV measures at the radiator and reads several degrees too warm. Its firmware
regulates on that reading, so a valve that believes the room is at 23 °C while the
room sensor says 21 °C closes early and the room stays cold. The valve exposes a
correction for exactly this: ``local_temperature_calibration``, an offset the
thermostat adds to its own measurement before it reports or regulates on it.

This used to live in the ``ga_hmvapp_addon`` add-on (ADR-0021, 2026-09-03). That loop
read the room temperature from an InfluxDB history that no longer exists on the new
device line, and — with nothing to compare against — wrote a calibration to every
valve every 3 s. Everything the loop needs is already in Home Assistant: the room
entity knows its valves and its room sensor, and the valve's reading and its offset
are entities of their own. So the decision moves here, next to the data.

Three guards make this a correction and not a flood:

* **A room without a dedicated sensor never calibrates its valves.** The room's
  temperature would then be one of the valves' own readings — calibrating a valve
  against itself is circular and would walk the offset to the limit.
* **A deadband.** Nothing is written while the valve is within 0.3 K of the room.
* **A rate limit.** At most one write per valve per 10 minutes, whatever the numbers
  say. The valve reports the new offset back on its own schedule; without the limit the
  stale ``number`` state would re-trigger the same write every tick.

What the offset means — the one assumption this module stands on
----------------------------------------------------------------
The valve is a stock ZCL Thermostat cluster device (zigbee2mqtt's TRVZB definition
uses ``fz.thermostat`` / ``tz.thermostat_local_temperature_calibration``, which only
scale the attributes ``localTemperature`` (/100) and ``localTemperatureCalibration``
(/10) — no arithmetic on either side). The ZCL Thermostat cluster defines
``LocalTemperatureCalibration`` as the offset the thermostat adds to its measured
temperature to form ``LocalTemperature``::

    local_temperature = measured + offset          (ZCL 0x0201 attrs 0x0000, 0x0010)

so the valve's *uncorrected* reading is ``local_temperature - offset``, and the offset
that makes the valve agree with the room is ``room - measured``. Verified against the
converter source (Koenkk/zigbee-herdsman-converters ``src/devices/sonoff.ts``,
``src/converters/{from,to}Zigbee.ts``) on 2026-09-03; that Sonoff's firmware follows
the ZCL definition is the assumption. If a valve ever reports ``local_temperature``
*without* the offset applied, :func:`calibration_offset` is the single place to fix.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from decimal import ROUND_HALF_DOWN, Decimal
from typing import TYPE_CHECKING, Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er
from homeassistant.util import dt as dt_util

from . import DOMAIN

if TYPE_CHECKING:
    from .climate import GARoomClimate

_LOGGER = logging.getLogger(__name__)

# Sonoff TRVZB, measured on K31 on 2026-09-03: min -12.7, max 12.7, step 0.2 (°C).
CALIBRATION_STEP = 0.2
CALIBRATION_LIMIT = 12.7
# Below this the valve and the room agree well enough; a write would only be noise
# (the valve's own reading is 0.1 K resolution anyway).
CALIBRATION_DEADBAND = 0.3
# A valve gets one write, then time to settle and report back. Anything shorter and a
# stale `number` state re-issues the same write on the next tick.
CALIBRATION_MIN_INTERVAL = timedelta(minutes=10)

CALIBRATION_SUFFIX = "_local_temperature_calibration"

# ── heating decision contract v1 (ADR-0021 §3, docs/contracts/heating-decision-contract.md) ──
# The closed decision engine (ga_hmvapp_addon) publishes ONE desired offset per valve as a
# retained MQTT-discovery sensor; this component is the only sender on the valve and applies
# the decision through the same guards as its own formula. Absent, expired, malformed or made
# for a room without a dedicated sensor → the physics formula below decides instead.
DECISION_CONTRACT_MAJOR = 1
DECISION_PREFIX = "sensor.hm_"
DECISION_SUFFIX = "_desired_offset"
LOCAL_TEMPERATURE_SUFFIX = "_local_temperature"


def calibration_offset(
    room_temp: float | None,
    valve_local_temp: float | None,
    current_offset: float | None,
    *,
    step: float = CALIBRATION_STEP,
    limit: float = CALIBRATION_LIMIT,
    deadband: float = CALIBRATION_DEADBAND,
) -> float | None:
    """The offset to write to a valve, or ``None`` when nothing should be written.

    ``valve_local_temp`` is what the valve REPORTS, which already includes the offset
    it currently applies (see the module docstring). The uncorrected measurement is
    therefore ``valve_local_temp - current_offset``, and the offset that makes the
    valve read like the room is ``room_temp - measured``.

    The result is quantised to ``step`` (a value exactly between two steps goes
    toward zero — the smaller correction) and clamped to ``±limit``. ``None`` means:
    an input is missing, or the change is smaller than ``deadband`` — a valve within
    the deadband is left alone, and so is one already sitting at the limit.
    """
    if room_temp is None or valve_local_temp is None or current_offset is None:
        return None
    measured = valve_local_temp - current_offset  # the valve's raw, uncorrected reading
    target = _quantise(room_temp - measured, step)
    target = max(-limit, min(limit, target))
    if abs(target - current_offset) < deadband:
        return None
    return target


def _quantise(value: float, step: float) -> float:
    """Nearest multiple of ``step``; an exact tie goes toward zero.

    In Decimal, deliberately. Readings have 0.1 K resolution and the step is 0.2 K,
    so every odd tenth is an exact tie — and whether ``-1.7 / 0.2`` is -8.5 or
    -8.4999… in binary is not a policy anyone chose.
    """
    q = Decimal(str(step))
    steps = (Decimal(str(round(value, 3))) / q).quantize(Decimal(1), rounding=ROUND_HALF_DOWN)
    return float(steps * q)


def calibration_entity_id(hass: HomeAssistant, valve: str) -> str | None:
    """The ``number`` entity carrying the valve's calibration.

    zigbee2mqtt names it ``number.<ieee>_local_temperature_calibration`` next to
    ``climate.<ieee>``, so the name is derived first. A valve that a resident renamed
    breaks that, so the fallback is the registry: the ``number`` entity on the same
    DEVICE whose id ends in the calibration suffix.
    """
    derived = f"number.{valve.removeprefix('climate.')}{CALIBRATION_SUFFIX}"
    if hass.states.get(derived) is not None:
        return derived
    registry = er.async_get(hass)
    entry = registry.async_get(valve)
    if entry is None or entry.device_id is None:
        return None
    for sibling in er.async_entries_for_device(registry, entry.device_id):
        if sibling.domain == "number" and sibling.entity_id.endswith(CALIBRATION_SUFFIX):
            return sibling.entity_id
    return None


def valve_local_temperature(hass: HomeAssistant, valve: str) -> float | None:
    """What the valve itself measures — the reading the offset is applied to.

    zigbee2mqtt publishes ``local_temperature`` twice: as the climate entity's
    ``current_temperature`` attribute and as ``sensor.<ieee>_local_temperature``. The
    attribute is read first because it lives on the entity the room already tracks;
    the sensor is the fallback for a valve whose climate entity carries no reading.
    """
    state = hass.states.get(valve)
    if state is not None and state.state not in ("unavailable", "unknown"):
        value = state.attributes.get("current_temperature")
        if value is not None:
            return _as_float(value)
    sensor = f"sensor.{valve.removeprefix('climate.')}{LOCAL_TEMPERATURE_SUFFIX}"
    sensor_state = hass.states.get(sensor)
    if sensor_state is not None and sensor_state.state not in ("unavailable", "unknown"):
        return _as_float(sensor_state.state)
    return None


def _as_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _records(hass: HomeAssistant) -> dict[str, dict[str, Any]]:
    """Per-valve memory of the last write: ``{valve: {offset, written_at}}``.

    Not persisted on purpose. After a restart the first tick may write once more —
    that is one write, and it re-asserts a value the valve should already hold.
    """
    return hass.data.setdefault(DOMAIN, {}).setdefault("calibration", {})


def calibration_attributes(hass: HomeAssistant, valves: list[str]) -> dict[str, Any]:
    """The room's view of its valves' calibration, for ``extra_state_attributes``.

    Every valve is listed, so "never written" cannot be confused with "never looked
    at": a valve this code has not touched shows ``offset: None``.
    """
    records = _records(hass)
    out: dict[str, Any] = {}
    for valve in valves:
        record = records.get(valve)
        written_at = record["written_at"] if record else None
        out[valve] = {
            "offset": record["offset"] if record else None,
            "written_at": written_at.isoformat() if written_at else None,
            "source": record.get("source") if record else None,
            "reason": record.get("reason") if record else None,
        }
    return out


def decision_entity_id(valve: str) -> str:
    """`climate.<ieee>` → `sensor.hm_<ieee>_desired_offset` (contract v1 naming)."""
    return f"{DECISION_PREFIX}{valve.removeprefix('climate.')}{DECISION_SUFFIX}"


def _warn_once(hass: HomeAssistant, key: str, message: str, *args: Any) -> None:
    """One warning per (valve, problem) — a contract problem repeats every minute otherwise."""
    seen = hass.data.setdefault(DOMAIN, {}).setdefault("calibration_warned", set())
    if key in seen:
        return
    seen.add(key)
    _LOGGER.warning(message, *args)


def read_decision(hass: HomeAssistant, valve: str, now: datetime) -> tuple[float, str] | None:
    """The engine's decision for this valve, or None when there is none to apply.

    Contract v1: the sensor's state is the desired offset; attributes carry `contract`
    (major version), `valid_until` (ISO-8601) and `reason`. Anything malformed is
    reported once and treated as "no decision" — the physics formula then decides, so a
    broken engine degrades to the open behaviour instead of freezing the valve.
    """
    entity = decision_entity_id(valve)
    state = hass.states.get(entity)
    if state is None or state.state in ("unavailable", "unknown", ""):
        return None
    attrs = state.attributes
    try:
        major = int(str(attrs.get("contract", "")).split(".")[0])
    except ValueError:
        major = -1
    if major != DECISION_CONTRACT_MAJOR:
        _warn_once(
            hass,
            f"{valve}:contract",
            "ga_heating: %s carries contract %r, this component speaks %d — ignored",
            entity,
            attrs.get("contract"),
            DECISION_CONTRACT_MAJOR,
        )
        return None
    desired = _as_float(state.state)
    if desired is None:
        _warn_once(
            hass,
            f"{valve}:state",
            "ga_heating: %s state %r is not a number — ignoring the decision",
            entity,
            state.state,
        )
        return None
    valid_until = dt_util.parse_datetime(str(attrs.get("valid_until", "")))
    if valid_until is None:
        _warn_once(
            hass,
            f"{valve}:valid_until",
            "ga_heating: %s has no parseable valid_until — ignoring the decision",
            entity,
        )
        return None
    if valid_until.tzinfo is None:
        valid_until = valid_until.replace(tzinfo=dt_util.UTC)
    if valid_until <= now:
        # Expired: the engine is silent or dead. Not a warning — the fallback IS the design.
        return None
    return desired, str(attrs.get("reason", "unspecified"))


def decided_offset(
    desired: float,
    current_offset: float | None,
    *,
    step: float = CALIBRATION_STEP,
    limit: float = CALIBRATION_LIMIT,
    deadband: float = CALIBRATION_DEADBAND,
) -> float | None:
    """Clamp and quantise the engine's desired offset; None when it is within the deadband
    of what the valve already holds (same guard as the formula path)."""
    if current_offset is None:
        return None
    target = max(-limit, min(limit, _quantise(desired, step)))
    if abs(target - current_offset) < deadband:
        return None
    return target


async def async_calibrate_valve(
    hass: HomeAssistant, room: GARoomClimate, valve: str, now: datetime
) -> float | None:
    """Decide for one valve and write if the guards allow. Returns what was written."""
    state = hass.states.get(valve)
    if state is None or state.state in ("unavailable", "unknown"):
        return None
    number = calibration_entity_id(hass, valve)
    if number is None:
        return None
    number_state = hass.states.get(number)
    if number_state is None or number_state.state in ("unavailable", "unknown"):
        # Without the current offset the raw reading is unknowable, and writing blind
        # is exactly the add-on's mistake.
        return None
    current = _as_float(number_state.state)
    room_temp = room.room_sensor_temperature
    valve_temp = valve_local_temperature(hass, valve)
    source, reason = "default", None
    decision = read_decision(hass, valve, now)
    if decision is not None:
        new = decided_offset(decision[0], current)
        source, reason = "hmvapp", decision[1]
    else:
        new = calibration_offset(room_temp, valve_temp, current)
    if new is None:
        return None
    last = _records(hass).get(valve)
    if last is not None and now - last["written_at"] < CALIBRATION_MIN_INTERVAL:
        return None
    await hass.services.async_call(
        "number", "set_value", {"entity_id": number, "value": new}, blocking=True
    )
    _records(hass)[valve] = {
        "offset": new,
        "written_at": now,
        "source": source,
        "reason": reason,
    }
    _LOGGER.info(
        "ga_heating: %s calibration %s → %s (room %s, valve %s, source %s%s)",
        valve,
        current,
        new,
        room_temp,
        valve_temp,
        source,
        f" / {reason}" if reason else "",
    )
    return new


async def async_calibrate_rooms(hass: HomeAssistant, now: datetime | None = None) -> int:
    """One pass over every room, from the minute tick. Returns the number of writes.

    Evaluated every tick, written rarely: the deadband and the rate limit decide. A
    room whose temperature is not a dedicated sensor's is skipped whole — see the
    module docstring for why that is not optional.
    """
    now = now if now is not None else dt_util.utcnow()
    if now.tzinfo is None:
        now = now.replace(tzinfo=dt_util.UTC)
    written = 0
    rooms: dict[str, GARoomClimate] = hass.data.get(DOMAIN, {}).get("room_entities") or {}
    for room in list(rooms.values()):
        if not room.has_room_sensor:
            # A decision published for such a room is a contract violation — the engine
            # has no room temperature there either. Said once per valve, never acted on.
            for valve in room.valves:
                if read_decision(hass, valve, now) is not None:
                    _warn_once(
                        hass,
                        f"{valve}:no_sensor",
                        "ga_heating: decision for %s ignored — room has no dedicated sensor",
                        valve,
                    )
            continue
        if room.room_sensor_temperature is None:
            continue
        touched = False
        for valve in room.valves:
            try:
                if await async_calibrate_valve(hass, room, valve, now) is not None:
                    written += 1
                    touched = True
            except Exception as err:  # one valve must not stop the others
                _LOGGER.warning("ga_heating: calibrating %s failed: %r", valve, err)
        if touched:
            # The attribute changed; a room is not polled, so it has to say so itself.
            room.async_write_ha_state()
    return written
