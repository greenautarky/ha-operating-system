"""The PID controller of HASmartThermostat, vendored for underfloor heating rooms.

VENDORED, NOT WRITTEN HERE. Source: ScratMan/HASmartThermostat, release 2026.10.2,
``custom_components/smart_thermostat/pid_controller/__init__.py`` — class ``PID`` only
(the autotuner is not taken). Itself "based on Arduino PID Library"
(https://github.com/br3ttb/Arduino-PID-Library). Changes against the original are
limited to: the autotuner and unused imports removed, and this docstring. The class
body is byte-identical to upstream (hence ``ruff: noqa``), so a fix upstream can be
compared line by line.

Licence (MIT), both notices kept as the licence requires:

  HASmartThermostat — Copyright (c) 2026 Adrien Bonnat
  pid_controller    — Copyright (c) 2018 The Python Packaging Authority

  Permission is hereby granted, free of charge, to any person obtaining a copy of this
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify,
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
  permit persons to whom the Software is furnished to do so, subject to the following
  conditions:

  The above copyright notice and this permission notice shall be included in all copies
  or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
  INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
  PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
  OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Why not HASmartThermostat as a whole: it is a second climate entity per room with its
own PWM and its own stall detection, and its stall detection ages the READING — wrong
for report-on-change room sensors, which this component already judges by the device's
radio heartbeat (``climate.sensor_silence``). ga_heating stays the only writer (ADR-0021).
"""
# ruff: noqa
import logging

_LOGGER = logging.getLogger(__name__)


# Based on Arduino PID Library
# See https://github.com/br3ttb/Arduino-PID-Library
class PID:
    error: float

    def __init__(
            self,
            kp,
            ki,
            kd,
            ke=0,
            out_min=float("-inf"),
            out_max=float("+inf"),
            sampling_period=0,
            cold_tolerance=0.3,
            hot_tolerance=0.3,
    ):
        """A proportional-integral-derivative controller.
        :param kp: Proportional coefficient.
        :type kp: float
        :param ki: Integral coefficient.
        :type ki: float
        :param kd: Derivative coefficient.
        :type kd: float
        :param ke: Outdoor temperature compensation coefficient.
        :type ke: float
        :param out_min: Lower output limit for integral anti-windup clamping.
        :type out_min: float
        :param out_max: Upper output limit for integral anti-windup clamping.
        :type out_max: float
        :param sampling_period: Time period between two PID calculations in seconds.
        :type sampling_period: float
        :param cold_tolerance: Temperature threshold tolerance below setpoint when OFF.
        :type cold_tolerance: float
        :param hot_tolerance: Temperature threshold tolerance above setpoint when OFF.
        :type hot_tolerance: float
        """
        if kp is None:
            raise ValueError("kp must be specified")
        if ki is None:
            raise ValueError("ki must be specified")
        if kd is None:
            raise ValueError("kd must be specified")
        if out_min >= out_max:
            raise ValueError("out_min must be less than out_max")

        self._Kp = kp
        self._Ki = ki
        self._Kd = kd
        self._Ke = ke
        self._out_min = out_min
        self._out_max = out_max
        self._proportional = 0.0
        self._integral = 0.0
        self._derivative = 0.0
        self._last_set_point = 0
        self._set_point = 0
        self._input = None
        self._input_time = None
        self._last_input = None
        self._last_input_time = None
        self._error = 0
        self._input_diff = 0
        self._dext = 0
        self._dt = 0
        self._last_output = 0
        self._output = 0
        self._external = 0
        self._mode = "AUTO"
        self._sampling_period = sampling_period
        self._cold_tolerance = cold_tolerance
        self._hot_tolerance = hot_tolerance

    @property
    def mode(self):
        return self._mode

    @mode.setter
    def mode(self, mode):
        assert mode.upper() in ["AUTO", "OFF"]
        self._mode = mode.upper()

    @property
    def out_max(self):
        return self._out_max

    @out_max.setter
    def out_max(self, out_max):
        self._out_max = out_max

    @property
    def out_min(self):
        return self._out_min

    @out_min.setter
    def out_min(self, out_min):
        self._out_min = out_min

    @property
    def sampling_period(self):
        return self._sampling_period

    @property
    def error(self):
        return self._error

    @property
    def proportional(self):
        return self._proportional

    @property
    def integral(self):
        return self._integral

    @integral.setter
    def integral(self, i):
        assert isinstance(i, float), "Integral should be a float"
        self._integral = i

    @property
    def derivative(self):
        return self._derivative

    @property
    def external(self):
        return self._external

    @property
    def dt(self):
        return self._dt

    def set_pid_param(self, kp=None, ki=None, kd=None, ke=None):
        """Set PID parameters dynamically."""
        if kp is not None and isinstance(kp, (int, float)):
            self._Kp = kp
        if ki is not None and isinstance(ki, (int, float)):
            self._Ki = ki
        if kd is not None and isinstance(kd, (int, float)):
            self._Kd = kd
        if ke is not None and isinstance(ke, (int, float)):
            self._Ke = ke

    def clear_samples(self):
        """Clear the samples values and timestamp to restart PID from clean state after
        a switch off of the thermostat."""
        self._input = None
        self._input_time = None
        self._last_input = None
        self._last_input_time = None
        self._integral = 0.0

    def calc(
            self, input_val, set_point, input_time=None, last_input_time=None, ext_temp=None
    ):
        """Adjusts and holds the given setpoint.

        Args:
            input_val (float): The input value.
            set_point (float): The target value.
            input_time (float): The timestamp in seconds of the input value to compute dt.
            last_input_time (float): The timestamp in seconds of the previous input value to compute dt.
            ext_temp (float): The outdoor temperature value.

        Returns:
            A tuple of (output, changed_flag). Output is the raw sum (clamping handled downstream).
        """
        self._last_input = self._input
        self._last_input_time = (
            last_input_time if last_input_time is not None else self._input_time
        )
        self._last_output = self._output

        # Refresh with actual values
        self._input = input_val
        self._input_time = input_time
        self._last_set_point = self._set_point
        self._set_point = set_point

        if self.mode == "OFF":
            # If PID is off, simply switch between min and max output
            if input_val <= set_point - self._cold_tolerance:
                self._output = self._out_max
                _LOGGER.debug("PID is off and input lower than set point: heater ON")
                return self._output, True
            elif input_val >= set_point + self._hot_tolerance:
                self._output = self._out_min
                _LOGGER.debug("PID is off and input higher than set point: heater OFF")
                return self._output, True
            else:
                return self._output, False

        # Compute all the working error variables
        self._error = set_point - input_val
        if self._last_input is not None:
            self._input_diff = self._input - self._last_input
        else:
            self._input_diff = 0
        if (
                self._last_input_time is not None
                and self._input_time > self._last_input_time
        ):
            self._dt = self._input_time - self._last_input_time
        else:
            self._dt = 0
        if ext_temp is not None:
            self._dext = set_point - ext_temp
        else:
            self._dext = 0

        # Feedforward compensation value for external temperature
        self._external = self._Ke * self._dext

        # Anti-windup clamping: only integrate if output is not saturated
        saturated_high = self._last_output >= self._out_max
        saturated_low = self._last_output <= self._out_min
        pushing_deeper = (saturated_high and self._error > 0) or (
                saturated_low and self._error < 0
        )

        if not pushing_deeper and self._dt > 0:
            self._integral += self._Ki * self._error * self._dt

        if self._Ki:
            # Clamp integral term taking external compensation into account
            i_min = self._out_min - self._external
            i_max = self._out_max - self._external
            self._integral = max(min(self._integral, i_max), i_min)

        # Proportional term
        self._proportional = self._Kp * self._error

        # Derivative term calculated on input to prevent derivative kick
        if self._dt > 0 and self._last_input is not None:
            self._derivative = -(self._Kd * self._input_diff) / self._dt
        else:
            self._derivative = 0.0

        # Compute raw PID Output (downstream climate component handles final output clamping)
        self._output = self._proportional + self._integral + self._derivative
        return self._output, True


# Based on a fork of Arduino PID AutoTune Library
