"""Initial/iterative hydraulic balancing (ICHB) as a ga_heating override.

Wired in since 0.13.0: effective_target ranks it (window > ichb > boost > absence >
slot), the services ``ga_heating.ichb`` / ``ga_heating.cancel_ichb`` start and stop
it, and the executor tick calls ``reap``. The INTEGRATION notes below record how it
was wired, for the next reader.

WHY HERE AND NOT IN A SCRIPT. ICHB today is scripts/hb_test.py in
ha-dashboard-automation, run by a GitHub workflow that SSHes into the device and writes
raw to ``zigbee2mqtt/<ieee>/set``. That makes it a second writer to the valves, which is
exactly the arrangement Contract 2 removed, and it means ga_heating never learns a
measurement is running. It is also barely cancellable (kill the Actions run and hope the
SIGTERM handler fires) and not restart-safe (if the process dies, every radiator stays
pinned in manual with nothing left to unpin it).

As an override it inherits both properties instead of reimplementing them. There is no
long-running task: the record carries ``until``, the executor re-applies on the tick
that already exists, and cancelling is removing a dict key. A restart mid-run reloads
the record with its deadline intact, so the run either continues correctly or expires.

WHAT ICHB NEEDS THAT boost DOES NOT. Three things, and they are why this is a module
rather than ten lines next to _boost:

  1. It is apartment-wide. Rates measured at different flows are not comparable, so
     every room is pinned at once and the run is one object, not one per room.
  2. It pins the VALVE, not just the setpoint. _apply only writes temperature and mode —
     the only valve write in the component is hmvapp.apply_opening_degree, and that is
     gated behind GA_HEATING_APPLY_OPENING_DEGREE because an hmvapp proposal is advisory.
     ICHB is not advisory: it is ga_heating acting as the writer it is declared to be. So
     it calls number.set_value itself and restores the previous value when the run ends.
  3. It has to admit when a radiator cannot be measured. An open window silently ruined a
     probe run on 2026-10-01: the TRV reverted a 25 °C setpoint within two seconds and
     held 19 °C for the rest of the window, while the old script slept out the hour and
     reported success. A measurement that cannot be taken must be reported, not averaged.

HOLDING THE CONDITION — why _hold() exists at all.
_apply writes only when the effective SOURCE KEY changes (__init__.py:792): "nothing
changed — the resident owns the dial". That rule is right for heating and wrong for a
measurement. The key is constant for the whole run, so without _hold ICHB would write
once at minute 0, and a resident turning a TRV down at minute 10 would keep their change
while the run carried on for another 50 minutes and reported success. Exactly the hole
the old script had, where the watchdog covered 5 minutes of 60.

So ICHB takes the room back: force=True pushes past that guard, and because
is_override is true for an "ichb:…" key it also passes the hands-off branch for
MANUAL/OFF rooms and the MODE_DEVICE "trust, then verify" branch. The licence for that
is operational, not technical — the tenant is told at commissioning that balancing runs
for the next hour. Outside that conversation this would be the wrong behaviour.

It re-asserts on DRIFT, not on a timer. Forcing every minute would push 60 setpoint
writes and 60 record_change rows per room through THE FUNNEL for an hour, for nothing.
Checking first also yields the contest count for free, and that number is how you judge
the hour afterwards: a run that had to be re-asserted fifteen times completed, but its
data is not worth the same as a quiet one.

INTEGRATION
  1. effective_target() in __init__.py — insert ICHB above boost, below window:

         ichb = ov.get("ichb")
         if isinstance(ichb, dict):
             until = _parse_dt(ichb.get("until"))
             temp = _parse_temp(ichb.get("temp"))
             if until is not None and temp is not None and when < until:
                 return f"ichb:{until.isoformat()}", temp

     DECIDED (2026-10-06): window > ichb > boost > absence > slot. ICHB outranks a
     boost because a boost mid-run corrupts the hour, but it does NOT outrank window —
     an open window invalidates the measurement anyway, and heating against one is the
     waste this component exists to prevent. The room is reported unmeasurable instead.

  2. async_register_services() in __init__.py — register the two handlers below.

  3. services.yaml — the two entries (in the reply that accompanied this sketch), plus
     translations/ if you want the form localised like boost and absence are.

  Also: reap() has to be called from whatever already ticks _apply, once a minute is
  plenty. Without it the override expires correctly but the valves are never restored.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.exceptions import ServiceValidationError

from . import (
    DOMAIN,
    ICHB_DEFAULT_MINUTES,
    ICHB_DEFAULT_TEMPERATURE,
    _apply,
    _overrides,
    _own_context,
    _republish_room,
    _save,
)
from .changelog import KIND_EVENT, SOURCE_BALANCING
from .changelog import record as record_change

_LOGGER = logging.getLogger(__name__)

SERVICE_ICHB = "ichb"
SERVICE_CANCEL_ICHB = "cancel_ichb"

#: Override key, and the source prefix effective_target returns.
ICHB_KEY = "ichb"

#: Valve ceiling held for the run. The whole point: compare radiators, not compare the
#: previous cycle's corrections.
ICHB_FULL_FLOW = 100

#: Same suffix hmvapp.py uses to find a valve's opening-degree number entity.
OPENING_NUMBER_SUFFIX = "_valve_opening_degree"

#: How far a room's setpoint may sit from the target before we take the room back.
#: Wider than a TRV's 0.5 °C step, so rounding on the device is not read as a resident.
ICHB_SETPOINT_TOLERANCE = 0.6


def _naive(when: datetime | None = None) -> datetime:
    """Local wall-clock, tz-naive — what every record here stores and compares against.

    ``async_track_time_change`` hands ``_tick`` a timezone-AWARE ``now`` while the run
    record and the overrides are naive, and comparing the two raises TypeError. ``_apply``
    normalises for exactly this reason (see the note in the tick, dated 2026-08-17).
    Found here the same way on 2026-10-06: ``reap`` threw once a minute, so the run never
    ended and the override was never cleaned up. Normalising at EVERY entry point means a
    caller cannot reintroduce it.
    """
    when = when or datetime.now()
    return when.astimezone().replace(tzinfo=None) if when.tzinfo is not None else when


# ── the run record ────────────────────────────────────────────────────────────

def run(hass: HomeAssistant) -> dict[str, Any] | None:
    """The ICHB run in force, or None.

    One per apartment, stored next to the plan so a restart does not lose the deadline
    or forget which valve ceilings it owes the resident.
    """
    return hass.data[DOMAIN]["state"].get("ichb_run")


def _set_run(hass: HomeAssistant, record: dict[str, Any] | None) -> None:
    state = hass.data[DOMAIN]["state"]
    if record is None:
        state.pop("ichb_run", None)
    else:
        state["ichb_run"] = record


def state_view(hass: HomeAssistant, now: datetime | None = None) -> dict[str, Any]:
    """What a card or a caller polling over REST should see.

    Mirrors override_view's contract: reads the same dict the engine reads, so the
    status shown and the decision made cannot drift apart.
    """
    now = _naive(now)
    record = run(hass)
    if not record:
        return {"state": "idle"}
    until = datetime.fromisoformat(record["until"])
    return {
        "state": "running" if now < until else "finishing",
        "run_id": record["run_id"],
        "started": record["started"],
        "until": record["until"],
        "remaining_s": max(0, int((until - now).total_seconds())),
        "rooms": sorted(record["rooms"]),
        # Named, not counted: "2 radiators unmeasurable" tells an operator nothing they
        # can act on.
        "unmeasurable": record.get("unmeasurable", {}),
        # How often the condition had to be taken back, per room. Not a failure — the
        # run still completes — but it is the difference between an hour of clean data
        # and an hour of data somebody kept interrupting, and only this number says
        # which one you have.
        "reasserts": record.get("reasserts", {}),
        "contested": bool(record.get("reasserts")),
    }


# ── measurability ─────────────────────────────────────────────────────────────

def _valves(hass: HomeAssistant, rooms: list[str]) -> dict[str, list[str]]:
    """``{room_entity: [valve_entity, …]}`` for the rooms in this run."""
    mapping = hass.data.get(DOMAIN, {}).get("rooms") or {}
    return {room: list(valves) for room, valves in mapping.items() if room in rooms}


def _room_measures_itself(hass: HomeAssistant, room: str) -> bool:
    """Does this room's reported temperature respond to THIS room being heated?

    The run compares radiators by how fast each warms its room, so a room whose
    number cannot move with its own radiator contributes a rate that belongs to
    something else.

    Since 0.13.4 a room with no thermometer of its own reports the HOUSE AVERAGE.
    That is the right number to heat on and the wrong one to measure with: it is
    the same figure in every sensorless room, and it moves with the rest of the
    flat rather than with the radiator under test. An hour of it yields a rate
    that looks perfectly plausible and means nothing — which is worse than no
    rate, because nothing says it is empty.

    A room reading its own VALVE still has a signal of its own heating. Biased
    warm, and the subject of a startup warning for years, but it does respond to
    this radiator — so it is left in, as it always has been. Only the average is
    excluded here.
    """
    state = hass.states.get(room)
    if state is None:
        return True            # unknown shape: not ours to exclude on a guess
    return (state.attributes or {}).get("temperature_source") != "house_average"


def _unmeasurable_reason(hass: HomeAssistant, valve: str) -> str | None:
    """Why this radiator cannot produce a catch-up rate this hour, or None.

    NOT open_window, and the reason is worth recording. On a Sonoff TRVZB the only
    open-window entity Home Assistant exposes is ``switch.<ieee>_open_window``, and that
    is the detection FEATURE's on/off setting — not "a window is open right now". All
    three radiators on KIB-SON-00000000 read ``on``, which is the firmware default and
    says nothing about any window; there is no "window currently detected" signal on this
    hardware at all. An earlier version of this function read an ``open_window``
    attribute off the climate entity, which does not exist there and so matched nothing;
    reading the switch instead would have been worse, excluding every radiator for ever.

    So this checks only what can actually be established today. Candidates worth adding
    once each has a verified signal behind it:
      * the room's temperature sensor is offline (hmvapp reports reason="sensor_offline",
        and heating_rate cannot compute a rate without it)
      * faults.owns(valve) — a fault remedy already holds this radiator
    """
    state = hass.states.get(valve)
    if state is None or state.state in ("unavailable", "unknown"):
        return "valve_unavailable"
    return None


# ── valve pinning ─────────────────────────────────────────────────────────────

def _opening_number(valve: str) -> str:
    return f"number.{valve.removeprefix('climate.')}{OPENING_NUMBER_SUFFIX}"


async def _pin_valve(hass: HomeAssistant, valve: str) -> int | None:
    """Open ``valve``'s ceiling to full flow; return what it was, for the restore.

    Returns None when there is nothing to restore — no number entity, or it already
    reads full flow. On hardware where the ceiling never moves (14 827 samples over 30
    days on KIB-SON-00000000, all 100.0) this is a no-op, which makes the first run a
    safe way to prove the write path works without changing anything.
    """
    number = _opening_number(valve)
    current = hass.states.get(number)
    if current is None or current.state in ("unavailable", "unknown"):
        _LOGGER.warning("ga_heating/ichb: %s has no opening-degree number entity", valve)
        return None
    try:
        previous = int(float(current.state))
    except ValueError:
        return None
    if previous == ICHB_FULL_FLOW:
        return None
    await hass.services.async_call(
        "number", "set_value",
        {"entity_id": number, "value": ICHB_FULL_FLOW},
        blocking=True, context=_own_context(hass),
    )
    _LOGGER.info("ga_heating/ichb: %s ceiling %s → %s", valve, previous, ICHB_FULL_FLOW)
    return previous


async def _restore_valve(hass: HomeAssistant, valve: str, previous: int) -> None:
    await hass.services.async_call(
        "number", "set_value",
        {"entity_id": _opening_number(valve), "value": previous},
        blocking=True, context=_own_context(hass),
    )
    _LOGGER.info("ga_heating/ichb: %s ceiling restored to %s", valve, previous)


# ── start / cancel / reap ─────────────────────────────────────────────────────

async def start(hass: HomeAssistant, *, minutes: int, temperature: float,
                rooms: list[str] | None = None, now: datetime | None = None
                ) -> dict[str, Any]:
    """Put every requested room into the measurement condition for ``minutes``."""
    now = _naive(now)

    if run(hass) is not None:
        # Not idempotent on purpose: silently restarting the clock would discard a run
        # someone is already waiting on, and two overlapping runs cannot both be the
        # measurement.
        raise ServiceValidationError(
            "an ICHB run is already in force; cancel it first"
        )

    known = list((hass.data.get(DOMAIN, {}).get("rooms") or {}).keys())
    target_rooms = rooms or known
    unknown = [r for r in target_rooms if r not in known]
    if unknown:
        raise ServiceValidationError(f"unknown room(s): {', '.join(sorted(unknown))}")
    if not target_rooms:
        raise ServiceValidationError("no rooms to balance")

    until = now + timedelta(minutes=minutes)
    record: dict[str, Any] = {
        "run_id": uuid.uuid4().hex,
        "started": now.isoformat(),
        "until": until.isoformat(),
        # Stored rather than read back out of an override, so _hold has one source of
        # truth for what it is holding the rooms to.
        "temp": temperature,
        "rooms": [],
        "unmeasurable": {},
        # {room_entity: count} — how many times _hold had to take the room back.
        "reasserts": {},
        # {valve: previous_ceiling} — the debt we owe the resident, persisted for the
        # same reason _restore_modes is: a restart has not cancelled it.
        "restore_openings": {},
    }

    # Overrides are written only after every ceiling is open. A start that fails
    # halfway gives back the ceilings it already opened and leaves no room heating
    # at the run temperature without a run record behind it — cancel_ichb could
    # not reach such a room.
    pinned_rooms: list[str] = []
    try:
        await _pin_rooms(hass, record, target_rooms, pinned_rooms)
    except Exception:
        for valve, previous in record["restore_openings"].items():
            try:
                await _restore_valve(hass, valve, int(previous))
            except Exception:  # one failed restore must not strand the others
                _LOGGER.exception("ga_heating/ichb: could not restore %s", valve)
        _LOGGER.error("ga_heating/ichb: start failed; ceilings given back, no run")
        raise

    # NAMED IN EVERY ROOM'S LOG. The setpoints the run writes are already there,
    # tagged `balancing`, but "Soll 19 -> 30" and an hour later "30 -> 19" only
    # reads as a balancing run to somebody who knows what one is. A resident who
    # was out gets the two lines that say so.
    for room in pinned_rooms:
        record_change(hass, room, KIND_EVENT, source=SOURCE_BALANCING,
                      to="ichb_started")

    for room in pinned_rooms:
        _overrides(hass).setdefault(room, {})[ICHB_KEY] = {
            "until": until.isoformat(),
            "temp": temperature,
            "run_id": record["run_id"],
        }
        record["rooms"].append(room)

    if not record["rooms"]:
        raise ServiceValidationError(
            "no radiator in this apartment can be measured right now: "
            + ", ".join(f"{v} ({r})" for v, r in record["unmeasurable"].items())
        )

    _set_run(hass, record)
    await _save(hass)
    for room in record["rooms"]:
        # Now, not at the next tick: the hour is being measured from this moment.
        await _apply(hass, room, now)
        _republish_room(hass, room)

    _LOGGER.info(
        "ga_heating/ichb: run %s started on %s until %s (%.1f °C, %d%% ceiling); "
        "excluded %s",
        record["run_id"], ", ".join(record["rooms"]), until.isoformat(),
        temperature, ICHB_FULL_FLOW, record["unmeasurable"] or "nothing",
    )
    return state_view(hass, now)


async def _pin_rooms(hass: HomeAssistant, record: dict[str, Any],
                     target_rooms: list[str], pinned_rooms: list[str]) -> None:
    """Open the ceilings of every measurable radiator; collect the rooms to hold.

    Fills ``record["restore_openings"]`` as it goes, so a caller that catches a
    failure knows exactly which ceilings to give back.
    """
    for room, valves in _valves(hass, target_rooms).items():
        if not _room_measures_itself(hass, room):
            # Named, not silently dropped: an hour that quietly left three rooms
            # out is an hour somebody has to run again.
            for valve in valves:
                record["unmeasurable"][valve] = "no_room_sensor"
            _LOGGER.warning(
                "ga_heating/ichb: %s excluded from the run — it has no thermometer of "
                "its own and is reporting the house average, which cannot show this "
                "room warming up", room,
            )
            continue
        measurable = []
        for valve in valves:
            reason = _unmeasurable_reason(hass, valve)
            if reason:
                record["unmeasurable"][valve] = reason
                _LOGGER.warning(
                    "ga_heating/ichb: %s excluded from the run (%s)", valve, reason
                )
                continue
            measurable.append(valve)

        if not measurable:
            # A room with no measurable radiator is not pinned at all: holding it at
            # the run temperature would heat it for an hour and produce nothing.
            _LOGGER.warning("ga_heating/ichb: %s has no measurable radiator", room)
            continue

        for valve in measurable:
            previous = await _pin_valve(hass, valve)
            if previous is not None:
                record["restore_openings"][valve] = previous
        pinned_rooms.append(room)


async def _finish(hass: HomeAssistant, *, cancelled: bool,
                  now: datetime | None = None) -> dict[str, Any] | None:
    """Take every room back off the measurement condition and settle the debts."""
    now = _naive(now)
    record = run(hass)
    if record is None:
        return None

    for room in record["rooms"]:
        (_overrides(hass).get(room) or {}).pop(ICHB_KEY, None)
        record_change(hass, room, KIND_EVENT, source=SOURCE_BALANCING,
                      to="ichb_cancelled" if cancelled else "ichb_ended")
    for valve, previous in (record.get("restore_openings") or {}).items():
        try:
            await _restore_valve(hass, valve, int(previous))
        except Exception:  # a restore failure must not strand the other valves
            _LOGGER.exception("ga_heating/ichb: could not restore %s", valve)

    _set_run(hass, None)
    await _save(hass)
    for room in record["rooms"]:
        await _apply(hass, room, now)  # the plan again
        _republish_room(hass, room)

    record["ended"] = now.isoformat()
    record["interrupted"] = cancelled
    contests = record.get("reasserts") or {}
    _LOGGER.info(
        "ga_heating/ichb: run %s %s at %s; condition taken back %s",
        record["run_id"], "cancelled" if cancelled else "complete", record["ended"],
        contests or "never",
    )
    # DECIDE: who writes fact_ihb_test. Either this component writes it (needs the
    # ga_database credential on the device, which is exactly what Contract 2 was moving
    # away from), or it fires an event and the caller that started the run records it.
    # The second keeps the credential in the workflow, where it already lives.
    hass.bus.async_fire(f"{DOMAIN}_ichb_finished", record)
    return record


async def cancel(hass: HomeAssistant, now: datetime | None = None
                 ) -> dict[str, Any] | None:
    """Stop the run and hand every room back. Idempotent."""
    return await _finish(hass, cancelled=True, now=now)


def _drift(hass: HomeAssistant, room: str, wanted: float) -> str | None:
    """Why ``room`` is no longer in the measurement condition, or None if it still is.

    Reads the room entity's own ``temperature`` attribute, which is what the radiators
    were actually set to rather than what we last intended — see GARoomClimate's
    target_temperature. Comparing against our intent would make this always agree with
    itself and never notice anything.
    """
    state = hass.states.get(room)
    if state is None or state.state in ("unavailable", "unknown"):
        # Not drift and not ours to fix. Reported so the hour can be judged, but no
        # write: there is nothing on the other end to write to.
        return "unavailable"
    if state.state == "off":
        return "switched_off"
    actual = state.attributes.get("temperature")
    if actual is None:
        return None
    try:
        if abs(float(actual) - wanted) > ICHB_SETPOINT_TOLERANCE:
            return f"setpoint_{actual}"
    except (TypeError, ValueError):
        return None
    return None


async def _hold(hass: HomeAssistant, record: dict[str, Any], now: datetime) -> None:
    """Take back any room or valve that has left the measurement condition.

    Writes only where something moved — see HOLDING THE CONDITION in the module
    docstring for why a timer would be the wrong shape.
    """
    wanted = float(record.get("temp") or ICHB_DEFAULT_TEMPERATURE)

    for room in list(record["rooms"]):
        if isinstance((_overrides(hass).get(room) or {}).get("window"), dict):
            # The window wins (effective_target) and the radiator is off: that is
            # not the resident taking the room back, it is a radiator this hour
            # cannot measure. Recorded once per valve, never re-asserted.
            for valve in _valves(hass, [room]).get(room, []):
                if record["unmeasurable"].get(valve) != "window_open":
                    record["unmeasurable"][valve] = "window_open"
                    _LOGGER.info(
                        "ga_heating/ichb: %s unmeasurable (window open)", valve
                    )
                    await _save(hass)
            continue
        reason = _drift(hass, room, wanted)
        if reason is None:
            continue
        if reason == "unavailable":
            _LOGGER.warning(
                "ga_heating/ichb: %s is unavailable mid-run; cannot hold it", room
            )
            continue
        if _late_echo_only(hass, room, wanted, now):
            # Not the room leaving the condition: its radiators are reporting a
            # setpoint WE sent them moments before the run (0.13.1, K31 2026-10-06:
            # wohnzimmer 30 → 20.5 a second into a run). Neither a reassert nor a
            # contest. Only for ECHO_WINDOW: a radiator still off the run after
            # that is taken back and counted on the next minute like any other.
            _LOGGER.info(
                "ga_heating/ichb: %s reads %s — the late echo of our own write, "
                "not a drift", room, reason,
            )
            continue
        record["reasserts"][room] = record["reasserts"].get(room, 0) + 1
        _LOGGER.info(
            "ga_heating/ichb: %s left the condition (%s) — taking it back (%d%s)",
            room, reason, record["reasserts"][room],
            " so far" if record["reasserts"][room] > 1 else "",
        )
        # force=True is what gets past __init__.py:792. The hands-off branch for a
        # MANUAL or OFF room is already skipped because an "ichb:…" key is an override.
        await _apply(hass, room, now, force=True)
        _republish_room(hass, room)

    # The ceiling is a separate write path from the setpoint, so it drifts separately.
    for valve in list((record.get("restore_openings") or {}).keys()) + _pinned_valves(
        hass, record
    ):
        number = _opening_number(valve)
        state = hass.states.get(number)
        if state is None or state.state in ("unavailable", "unknown"):
            continue
        try:
            if int(float(state.state)) == ICHB_FULL_FLOW:
                continue
        except ValueError:
            continue
        _LOGGER.info(
            "ga_heating/ichb: %s ceiling drifted to %s — back to %d%%",
            valve, state.state, ICHB_FULL_FLOW,
        )
        await hass.services.async_call(
            "number", "set_value",
            {"entity_id": number, "value": ICHB_FULL_FLOW},
            blocking=True, context=_own_context(hass),
        )

    if record["reasserts"]:
        await _save(hass)


def _late_echo_only(hass: HomeAssistant, room: str, wanted: float, now: datetime
                    ) -> bool:
    """Is every radiator of ``room`` that is off ``wanted`` only echoing a setpoint we
    sent it within ECHO_WINDOW? False when none is off it — then it is not a setpoint
    drift and this has nothing to explain."""
    # Imported here, as calibration.py and hmvapp.py do: climate pulls in the whole
    # entity platform, which this module must not need just to be imported.
    from .climate import GARoomClimate, recent_own_write

    off_run = []
    for valve in _valves(hass, [room]).get(room, []):
        state = hass.states.get(valve)
        if state is None or state.state in ("unavailable", "unknown"):
            continue
        temp = state.attributes.get("temperature")
        try:
            if temp is None or abs(float(temp) - wanted) <= ICHB_SETPOINT_TOLERANCE:
                continue
        except (TypeError, ValueError):
            continue
        off_run.append((valve, state, temp))
    if not off_run:
        return False
    return all(
        recent_own_write(
            hass, valve, state.state, temp, GARoomClimate._own_tolerance(state), now=now
        ) is not None
        for valve, state, temp in off_run
    )


def _pinned_valves(hass: HomeAssistant, record: dict[str, Any]) -> list[str]:
    """Valves in the run that had nothing to restore, so are absent from the debt list.

    A valve already at full flow when the run started is not in ``restore_openings``,
    but it still has to be held there — on hardware where the ceiling never moves that
    is EVERY valve, so leaving them out would make the ceiling half of the hold a no-op.
    """
    owed = set((record.get("restore_openings") or {}).keys())
    out: list[str] = []
    for valves in _valves(hass, record["rooms"]).values():
        out.extend(v for v in valves if v not in owed
                   and v not in (record.get("unmeasurable") or {}))
    return out


async def reap(hass: HomeAssistant, now: datetime | None = None) -> None:
    """Hold the condition, and finish the run when its time is up. Call from _tick.

    effective_target stops honouring the override by itself once ``until`` passes, so
    the rooms would return to plan without this — but the valve ceilings would stay
    where ICHB put them, and nothing would ever record that the run ended.
    """
    now = _naive(now)
    record = run(hass)
    if record is None:
        return
    if now >= datetime.fromisoformat(record["until"]):
        await _finish(hass, cancelled=False, now=now)
        return
    await _hold(hass, record, now)


# ── service handlers ──────────────────────────────────────────────────────────

async def async_handle_ichb(hass: HomeAssistant, call: ServiceCall) -> None:
    await start(
        hass,
        minutes=call.data.get("minutes", ICHB_DEFAULT_MINUTES),
        temperature=call.data.get("temperature", ICHB_DEFAULT_TEMPERATURE),
        rooms=call.data.get("rooms"),
    )


async def async_handle_cancel_ichb(hass: HomeAssistant, call: ServiceCall) -> None:
    await cancel(hass)
