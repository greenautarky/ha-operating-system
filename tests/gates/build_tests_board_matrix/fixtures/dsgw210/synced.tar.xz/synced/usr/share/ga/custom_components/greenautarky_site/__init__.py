"""greenautarky_site — the deployment-site management plane.

One GA device = one SITE (a home, an office, any installation). This
component owns everything about that site and its people:

* ``onboarding/`` — the one-shot setup wizard (PIN → GDPR → account →
  telemetry → ethernet → complete) + PIN-gated password reset. The built
  frontend Lit panel is served at /greenautarky-setup.html and registered
  as a sidebar panel for the mobile app.
* ``household/`` — the master user + the sub-users they invite
  (invite/join/assign/remove lifecycle, dashboard assignment).
* ``scoping/`` — the per-sub-user visibility boundary (room matrix →
  native entity permissions [Stage A] + leak guard [Stage B]) and the
  server-side home_model the ga-home dashboard strategy renders (#569).
* consent re-confirmation via the HA repairs system, and the
  fleet-manager's signed-token console login.

This file is WIRING ONLY: storage load + migrations, view registration,
panel/static/redirect registration, boot-deferred reconciles. Business
logic lives in the packages above — see docs/ARCHITECTURE.md.

Renamed from ``greenautarky_onboarding`` 2026-07-23 (Odoo #574): the
component manages the whole site lifecycle, not just onboarding.

This is the custom_component form of the integration. It used to live as a
built-in component in our HA Core fork (greenautarky/ha-core branch
ga/custom-onboarding); migrated 2026-05-XX to decouple from HA Core
lifecycle. See ga-ihost-docs/MIGRATION-CUSTOM-COMPONENT.md.

Two changes vs. the built-in version that lived in the fork:
1. Frontend assets (HTML + JS bundles) are bundled inside this component
   and registered via `async_register_static_paths` — they used to be
   shipped via the GA-customized home-assistant-frontend PyPI package.
2. The `/` → `/greenautarky-setup.html` redirect was a patch to
   `frontend/__init__.py` `IndexView.get()` in the fork; it is now a
   client-side JS module injected via `frontend.add_extra_js_url`.
   (The aiohttp-middleware approach tried in v0.1.x does not work from
   a custom_component — the middleware list is frozen by setup time;
   see ga-ihost-docs/MIGRATION-CUSTOM-COMPONENT-FINDINGS.md Finding 20.)
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import voluptuous as vol
from aiohttp import web
from homeassistant.components import frontend, panel_custom
from homeassistant.components.frontend import EVENT_PANELS_UPDATED, add_extra_js_url
from homeassistant.components.http import StaticPathConfig
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EVENT_HOMEASSISTANT_STARTED
from homeassistant.core import CoreState, Event, HomeAssistant, callback
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers import instance_id
from homeassistant.helpers.storage import Store
from homeassistant.helpers.typing import ConfigType

from .consent import async_check_and_create_issues
from .consent_views import (
    GAConsentAcceptView,
    GAConsentPageView,
    GAConsentStatusView,
)
from .console_login import GAConsoleLoginView, _migrate_legacy_console_secret
from .const import DOMAIN, STORAGE_KEY, STORAGE_VERSION
from .household import (
    GAHouseholdResetView,
    GAMasterConsolePageView,
    GASiteResetRequestView,
    GASiteResetStatusView,
    GASubUserAssignDashboardView,
    GASubUserInviteView,
    GASubUserJoinPageView,
    GASubUserJoinView,
    GASubUserManageView,
    GASubUserRemoveView,
    GASubUserRenameAreaView,
    GASubUserSetEnabledView,
    GASubUserSetMasterView,
    async_boot_register_personal_dashboards,
)
from .onboarding import (
    GAAdminBypassView,
    GALedConfigView,
    GAOnboardingCompleteView,
    GAOnboardingCreateUserView,
    GAOnboardingEthernetView,
    GAOnboardingGDPRView,
    GAOnboardingPageView,
    GAOnboardingResetView,
    GAOnboardingStatusView,
    GAOnboardingTelemetryView,
    GAPasswordResetPageView,
    GAPasswordResetUsersView,
    GAPasswordResetView,
    GAPinVerifyView,
)
from .onboarding.forgot_password_link import async_patch_authorize_page
from .onboarding.pin import _migrate_legacy_pin
from .rooms_sync import GARoomsSyncView
from .scoping import (
    GAEntityScopingView,
    GAHomeModelView,
    GAMyRoomsView,
    GASubUserAssignRoomView,
    async_install_home_strategy,
)
from .store import _get_state

_LOGGER = logging.getLogger(__name__)

URL_BASE = "/greenautarky_site_static"
PANEL_URL_PATH = "greenautarky-setup-panel"

# HA (2024.x+) quietly stops calling `async_setup` for a YAML-listed component
# that doesn't declare a CONFIG_SCHEMA. ga_manager's converge enables this
# integration by adding a BARE `greenautarky_site:` key to configuration.yaml,
# so the schema must keep accepting that (value `None`) — otherwise the
# component would only ever come up via config_flow (fragile on HA 2025.11.x).
#
# It used to be `cv.empty_config_schema(DOMAIN)`, which accepts the bare key and
# logs an ERROR for anything under it ("the greenautarky_site integration does
# not support any configuration parameters"). That was wrong twice over: the
# sweep below had documented `hide_default_panels: false` as its way back since
# the day it was written, so an operator who followed the comment got a config
# error telling them the key does not exist AND a sweep that ran anyway.
CONF_HIDE_DEFAULT_PANELS = "hide_default_panels"

_SITE_OPTIONS_SCHEMA = vol.Schema(
    {vol.Optional(CONF_HIDE_DEFAULT_PANELS, default=True): cv.boolean}
)

CONFIG_SCHEMA = vol.Schema(
    # `vol.Any(None, …)` is the bare-key form; a typo inside the block is a
    # hard Invalid rather than a silently ignored line.
    {DOMAIN: vol.Any(None, _SITE_OPTIONS_SCHEMA)},
    extra=vol.ALLOW_EXTRA,
)

# Where `async_setup` parks the validated YAML block for `_async_setup_common`.
# Separate from `hass.data[DOMAIN]` (the runtime state), which the re-entry
# guard keys on.
DATA_YAML_CONFIG = f"{DOMAIN}_yaml_config"

# Unsubscribe handle for the stock-panel invariant (see _hide_default_ha_panels).
DATA_PANEL_SWEEP_UNSUB = f"{DOMAIN}_panel_sweep_unsub"

# URL of the client-side `/` → wizard redirect JS module (Finding 20 fix).
REDIRECT_JS_URL = "/greenautarky_site_redirect.js"

DEFAULT_STATE: dict[str, Any] = {
    "completed": False,
    "gdpr_accepted": False,
    "steps_done": [],
    "consents": {},
}


def _migrate_v1_to_v2(state: dict[str, Any]) -> dict[str, Any]:
    """Migrate storage from v1 to v2: add consents dict.

    If GDPR was already accepted during onboarding, seed consents.gdpr
    with version 1 so the user isn't immediately prompted to re-confirm.
    """
    if "consents" not in state:
        state["consents"] = {}
    if state.get("gdpr_accepted") and "gdpr" not in state["consents"]:
        state["consents"]["gdpr"] = {
            "version": 1,
            "accepted_at": "migrated-from-v1",
        }
    return state


# The component was renamed greenautarky_onboarding → greenautarky_site
# (Odoo #574). Devices provisioned before the rename carry their whole
# household state (completed flag, consents, sub_users, sub_user_areas, …)
# under the OLD storage key — without this one-time move every such device
# would fall back into the onboarding wizard and lose its sub-user maps.
LEGACY_STORAGE_KEY = "greenautarky_onboarding"


async def _async_load_legacy_state(hass: HomeAssistant) -> dict[str, Any] | None:
    """Load + REMOVE the pre-rename store. Returns its data, or None.

    ⚠️ This deliberately goes through the Store API (async_load/async_remove),
    NOT a filesystem move: HA's store manager caches the `.storage` directory
    listing at boot, so a file created/moved behind its back is reported as
    absent by a later ``Store.async_load`` — exactly how the first cut of this
    migration silently produced an EMPTY state on K0 (2026-07-23) while the
    unit test (which never called Store) stayed green. The legacy file was
    present at boot, so loading it via Store is cache-coherent; async_remove
    deletes it coherently too — one source of truth afterwards (a stale copy
    would hold personal data the tenant-wipe could miss).
    """
    legacy_store: Store[dict[str, Any]] = _MigratableStore(
        hass, STORAGE_VERSION, LEGACY_STORAGE_KEY
    )
    data = await legacy_store.async_load()
    if data is None:
        return None
    await legacy_store.async_remove()
    _LOGGER.info(
        "storage migrated: .storage/%s -> .storage/%s", LEGACY_STORAGE_KEY, STORAGE_KEY
    )
    return data


class _MigratableStore(Store):
    """A Store subclass that knows how to migrate v1 → v2 state.

    Required because HA's base Store raises NotImplementedError from
    `_async_migrate_func` if a stored entry has a version OLDER than
    the one we pass to `Store(hass, STORAGE_VERSION, ...)`. Without this
    override, ANY v1 state file on disk would crash setup outright —
    which is exactly how K31 BOSv1.2.6 bench testing caught the gap.
    """

    async def _async_migrate_func(
        self,
        old_major_version: int,
        old_minor_version: int,
        old_data: dict[str, Any],
    ) -> dict[str, Any]:
        if old_major_version < 2:
            return _migrate_v1_to_v2(old_data)
        return old_data


async def _async_setup_common(hass: HomeAssistant) -> bool:
    """Shared setup logic — called from both async_setup (yaml) and async_setup_entry (config_flow).

    Idempotent: re-entry detected via DOMAIN-in-hass.data.
    """
    if DOMAIN in hass.data:
        return True

    # #762: the device's cloud identity (the default add-on) resolves its
    # device_id from HA's instance id (.storage/core.uuid), which HA writes
    # only lazily the first time something asks for it — and on a GA device
    # nothing asks, so a fresh, fully-onboarded device shipped telemetry with
    # no device_id at all (measured on K31, 2026-09-04). Ask for it here, on
    # every setup, so core.uuid always exists. Best-effort: identity is not
    # worth failing setup over.
    try:
        await instance_id.async_get(hass)
    except Exception:  # best-effort; setup must not fail on the instance id
        _LOGGER.warning(
            "could not ensure the HA instance id (core.uuid); cloud telemetry "
            "may lack a device identity until it is created"
        )

    # Use the migration-aware Store subclass — without it any state file
    # written by a prior version (v1) crashes setup with NotImplementedError
    # on the base _async_migrate_func. See _MigratableStore docstring.
    store: Store[dict[str, Any]] = _MigratableStore(hass, STORAGE_VERSION, STORAGE_KEY)
    state = await store.async_load()

    if state is None:
        # Rename migration (#574): nothing under the new key — adopt the
        # pre-rename store's state if there is one (Store-API-coherent; see
        # _async_load_legacy_state). The save immediately persists it under
        # the new key so the next boot is a plain load.
        state = await _async_load_legacy_state(hass)
        if state is not None:
            await store.async_save(state)

    # `loaded_from_storage` distinguishes a real GA-provisioned device from
    # an old / pre-existing one. See the `state is None` branch below.
    loaded_from_storage = state is not None

    if state is None:
        # No stored onboarding state.
        #
        # A factory-provisioned GA device ALWAYS has this storage entry —
        # provisioning stage 91 writes it (completed=false, tenant_mode=true)
        # so the wizard runs on first boot.
        #
        # Its ABSENCE therefore means this is NOT a freshly GA-provisioned
        # device: it is an OLD device that was set up before GA onboarding
        # existed (or any device the installer chose not to trigger). Such a
        # customer is already up and running — they must NOT be dragged into
        # the onboarding wizard. Default to completed=true: no wizard, no
        # `/` redirect, no sidebar panel. The API views are still registered
        # (harmless) so a later explicit trigger can still start the wizard.
        #
        # To deliberately run the wizard on such a device, write the
        # storage entry explicitly (installer SET_TRIGGER=always, or the
        # factory pipeline). Presence of the storage entry is the wizard
        # opt-in signal.
        state = {
            "completed": True,
            "tenant_mode": False,
            "gdpr_accepted": False,
            "steps_done": [],
            "consents": {},
        }
        _LOGGER.info(
            "No greenautarky onboarding state stored — treating device as "
            "already onboarded (no wizard). This is expected on devices "
            "field-upgraded from before GA onboarding existed."
        )
    elif "consents" not in state:
        state = _migrate_v1_to_v2(state)
        await store.async_save(state)

    hass.data[DOMAIN] = {"store": store, "state": state}

    # Register onboarding HTTP views (always — status check needs to work)
    hass.http.register_view(GAOnboardingPageView())
    hass.http.register_view(GAAdminBypassView())
    hass.http.register_view(GAOnboardingStatusView())
    hass.http.register_view(GAOnboardingGDPRView())
    hass.http.register_view(GAOnboardingTelemetryView())
    hass.http.register_view(GALedConfigView())
    hass.http.register_view(GAOnboardingEthernetView())
    # ADR-0008 / KB #184: GACI pushes the flat's rooms in at
    # installation, before anyone has onboarded. Reached through
    # Supervisor's Core proxy, so it needs no user account.
    hass.http.register_view(GARoomsSyncView())
    hass.http.register_view(GAOnboardingCompleteView())
    hass.http.register_view(GAOnboardingCreateUserView())
    hass.http.register_view(GAOnboardingResetView())
    hass.http.register_view(GAPinVerifyView())

    # Sub-user (household) management — ADR-0006. Registered ALWAYS (the
    # join flow is repeatable and runs AFTER device onboarding completes,
    # unlike the one-shot wizard views above). Invite issuing is master-only
    # (authenticated); join + join-page are invite-PIN-gated (unauthenticated).
    hass.http.register_view(GASubUserInviteView())
    hass.http.register_view(GASubUserJoinPageView())
    hass.http.register_view(GASubUserJoinView())

    # Master management plane (PROTOTYPE) — ADR-0006. Master-authenticated,
    # in-process privileged ops (dashboard assign + room rename); set_master is
    # admin-only (prod provisioning = ga_manager). Entity rename is deferred.
    hass.http.register_view(GASubUserSetMasterView())
    hass.http.register_view(GASubUserManageView())
    hass.http.register_view(GASubUserAssignDashboardView())
    hass.http.register_view(GASubUserRenameAreaView())
    # ADR-0006 lifecycle (main user manages own sub-users): remove + enable/disable.
    hass.http.register_view(GASubUserRemoveView())
    hass.http.register_view(GASubUserSetEnabledView())
    hass.http.register_view(GAMasterConsolePageView())
    # Danger Zone (KB #169): the household can unmake itself. Soft reset is
    # Core-side; the site reset only FILES a request that ga_manager executes.
    hass.http.register_view(GAHouseholdResetView())
    hass.http.register_view(GASiteResetRequestView())
    hass.http.register_view(GASiteResetStatusView())

    # Room-scoped dashboards: the master grants ROOMS, and the single shared
    # dashboard is generated per logged-in user by the ga-home strategy.
    hass.http.register_view(GAMyRoomsView())
    hass.http.register_view(GAHomeModelView())
    hass.http.register_view(GASubUserAssignRoomView())
    hass.http.register_view(GAEntityScopingView())

    # v1.0.0 shipped the console-login HMAC secret at `/share/ga/…` —
    # addon-readable, an exfil risk. v1.0.1+ keeps it under `/config/` and
    # migrates the old file on first boot. Best-effort: failures log a
    # warning, do NOT block setup (operator can fix perms; the view will
    # respond 503 until the secret is in the new location).
    await hass.async_add_executor_job(_migrate_legacy_console_secret)

    # v1.0.0..1.0.2 stored the onboarding PIN at `/config/ga-onboarding-pin`
    # — readable by any addon that maps `[config:rw]`. v1.0.3+ moves it
    # under `.storage/greenautarky_secrets/onboarding_pin` (= HA Core
    # convention for private files). Same migration shape as the console
    # secret above; same best-effort policy.
    await hass.async_add_executor_job(_migrate_legacy_pin, hass)

    # Signed-token auto-login from the fleet-manager UI's "Launch admin
    # console" button. See GAConsoleLoginView for the token contract.
    hass.http.register_view(GAConsoleLoginView())

    # Password reset views (unauthenticated, PIN-gated)
    hass.http.register_view(GAPasswordResetPageView())
    hass.http.register_view(GAPasswordResetUsersView())
    hass.http.register_view(GAPasswordResetView())
    # The login page's stock "Forgot password?" goes to home-assistant.io;
    # point it at the PIN reset above (ADR-0040). Never blocks setup.
    await async_patch_authorize_page(hass)

    # Consent HTTP views (authenticated, always available)
    hass.http.register_view(GAConsentPageView())
    hass.http.register_view(GAConsentStatusView())
    hass.http.register_view(GAConsentAcceptView())

    # Bundled frontend assets — used to be shipped via the GA-customized
    # home-assistant-frontend PyPI package. Now bundled with this component
    # so we don't need a forked frontend at all.
    await _async_register_frontend_bundle(hass)

    # Hide HA's stock sidebar panels that the GA tenant flow doesn't use.
    # Keeps the sidebar focused on the GA-relevant surface (Übersicht +
    # the addons + settings only). The panels are still defined in HA Core
    # — they just don't appear in the sidebar (and the routes 404 from
    # the operator's perspective). Reversible without a redeploy: set
    # `greenautarky_site: hide_default_panels: false` in configuration.yaml
    # + restart Core to bring them back. That key is READ here — see
    # CONFIG_SCHEMA and DATA_YAML_CONFIG above.
    #
    # Why here, not via a Lovelace strategy: panel visibility is a
    # frontend-config concern that exists outside of dashboard rendering.
    # frontend.async_remove_panel is the canonical HA API.
    yaml_config = hass.data.get(DATA_YAML_CONFIG) or {}
    if yaml_config.get(CONF_HIDE_DEFAULT_PANELS, True):
        _hide_default_ha_panels(hass)
    else:
        _LOGGER.info(
            "greenautarky_site: %s is false — leaving Home Assistant's stock "
            "sidebar panels alone",
            CONF_HIDE_DEFAULT_PANELS,
        )

    # Sidebar panel (mobile app), only shown while onboarding incomplete
    if not state.get("completed"):
        await _async_register_panel(hass)
        _LOGGER.info("greenautarky onboarding available at /greenautarky-setup")

    # Install the `/` → wizard redirect as a client-side JS module
    # injected into the HA frontend (replaces the aiohttp middleware
    # approach, which cannot work from a custom_component — Finding 20).
    if not state.get("completed"):
        _register_redirect_js(hass)
        # ALSO install a server-side patch on IndexView.get so the redirect
        # works for the FIRST visit, before any HA JS bundle loads. Without
        # this the customer sees the HA stock onboarding/login on a fresh
        # device because add_extra_js_url only injects into the
        # authenticated dashboard HTML (never into /onboarding.html nor
        # /auth/authorize) — confirmed in HA Core 2025.11.x source.
        _patch_index_view_for_wizard_redirect(hass)

    # Dashboards, deferred to EVENT_HOMEASSISTANT_STARTED so lovelace + auth are up:
    #  1. the default Overview is (re)pointed at the ga-home strategy — that IS the
    #     household dashboard now, generated per logged-in user from his rooms;
    #  2. legacy per-user boards (`ga-home-<name>`, ADR-0006 v1) are re-registered so
    #     they keep working until they are migrated away.
    async def _dashboards_started(_event: Event | None = None) -> None:
        # Site defaults FIRST — the strategy below renders from the rooms, and
        # the room names are a translation lookup against the site language.
        # Both only apply while GA onboarding is incomplete (= fresh device or
        # just reset): German is the product default and nothing else ever set
        # it, and HA creates its default areas only in its own onboarding,
        # which the wipe leaves marked done while wiping the area registry
        # (KB #169). No-op during normal tenancy.
        from .site_defaults import async_apply_site_defaults

        try:
            await async_apply_site_defaults(hass, _get_state(hass) or {})
        except Exception:
            _LOGGER.exception("site defaults: applying failed")

        await async_install_home_strategy(hass)
        await async_boot_register_personal_dashboards(hass)
        # Stage A: (re)apply per-user entity scopes from the room matrix. No-op
        # for real sub-users only (no-op without sub_users); self-heals any
        # leftover scope. Runs here so the entity/area registries + auth are up.
        from .scoping import entity_scope

        try:
            await entity_scope.async_reconcile_all(hass, _get_state(hass) or {})
        except Exception:
            _LOGGER.exception("entity_scope: boot reconcile failed")

        # Stage B: wrap the read paths Core does not check against the entity
        # policy (history/logbook/registry-lists/render_template). Idempotent
        # and a pass-through for every non-scoped user, so it installs
        # unconditionally — it only ever restricts a genuinely scoped sub-user.
        from .scoping import leak_guard

        try:
            leak_guard.install(hass)
        except Exception:
            _LOGGER.exception("leak_guard: install failed")

    if hass.state is CoreState.running:
        hass.async_create_task(_dashboards_started())
    else:
        hass.bus.async_listen_once(EVENT_HOMEASSISTANT_STARTED, _dashboards_started)

    # Check for outdated consents and create repair issues if needed.
    # Only for devices with a REAL stored onboarding state — an old device
    # with no stored state never gave GA consent, so consent-version checks
    # would just produce spurious "please re-confirm" repair issues.
    if loaded_from_storage and state.get("completed"):
        async_check_and_create_issues(hass, state)

    return True


async def async_setup(hass: HomeAssistant, config: ConfigType) -> bool:
    """Yaml-style setup (legacy / fallback path).

    Lets `greenautarky_site:` in configuration.yaml still work.
    Modern install path uses config_entry → async_setup_entry.

    HA calls this for a config-entry integration too, before it sets the
    entries up — so parking the YAML block here is what makes the options
    readable from BOTH paths. A device with no `greenautarky_site:` key parks
    ``{}`` and every option keeps its default.
    """
    block = config.get(DOMAIN)
    hass.data[DATA_YAML_CONFIG] = dict(block) if isinstance(block, dict) else {}
    return await _async_setup_common(hass)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Config-entry setup (Variant B — triggered by storage entry on restart).

    Installer or HAOS overlay writes a config_entry to
    `.storage/core.config_entries`; HA Core then calls this on next start.
    """
    return await _async_setup_common(hass)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Clean up on unload.

    NOTE: HA Core does not currently support removing registered HTTP views
    or middlewares at runtime. Unloading + reloading the integration
    in a single HA Core process will leak duplicate handlers. A full HA
    Core restart is needed for a clean unload. This is acceptable because
    the integration is install-once / live-forever (customer onboarding
    state is permanent).
    """
    _detach_panel_sweep(hass)
    hass.data.pop(DOMAIN, None)
    return True


async def _async_register_frontend_bundle(hass: HomeAssistant) -> None:
    """Register the bundled HTML + JS assets as HA static paths.

    Originally these were served by the GA-customized home-assistant-frontend
    PyPI package; now bundled inside this component. URL paths match the
    upstream registrations (/greenautarky-setup.html, /frontend_latest/...,
    /frontend_es5/...) so the HTML's hardcoded asset references continue to
    work.

    NOTE: HA's `frontend` component also registers `/frontend_latest` and
    `/frontend_es5` as broad static directories. Our specific-file
    registrations take precedence for the greenautarky bundles. If we
    later see asset 404s, this would be the first place to look.
    """
    # The filesystem scan runs in an executor — iterdir()/exists() are
    # blocking calls and must not run inside the event loop (Finding 21).
    configs = await hass.async_add_executor_job(_scan_frontend_bundle)
    if configs is None:
        _LOGGER.error(
            "frontend_bundle/ missing — wizard HTML will 404. "
            "Reinstall the custom_component."
        )
        return

    await hass.http.async_register_static_paths(configs)
    _LOGGER.debug("Registered %d static paths for the wizard bundle", len(configs))


def _scan_frontend_bundle() -> list[StaticPathConfig] | None:
    """Synchronously scan frontend_bundle/ and build StaticPathConfig list.

    Runs in an executor (filesystem I/O). Returns None if the bundle dir
    is missing.
    """
    bundle_dir = Path(__file__).parent / "frontend_bundle"
    if not bundle_dir.exists():
        return None

    configs = [
        StaticPathConfig(
            "/greenautarky-setup.html",
            str(bundle_dir / "greenautarky-setup.html"),
            True,
        ),
        # The `/` → wizard redirect JS module (injected via add_extra_js_url).
        StaticPathConfig(
            REDIRECT_JS_URL,
            str(bundle_dir / "ga-onboarding-redirect.js"),
            True,
        ),
    ]
    # Hashed JS bundles. Since #512 the wizard is a dedicated compilation
    # whose publicPath is the component's own static mount — serve the whole
    # dirs there (directory registration). The legacy per-file registrations
    # under the stock /frontend_latest|es5 URLs stay for the entry files so a
    # not-yet-regenerated (pre-#512) HTML keeps working during the transition.
    for sub in ("frontend_latest", "frontend_es5"):
        sub_dir = bundle_dir / sub
        if not sub_dir.exists():
            continue
        configs.append(
            StaticPathConfig(f"{URL_BASE}/{sub}", str(sub_dir), True)
        )
        for file in sub_dir.iterdir():
            if file.is_file() and file.name.startswith("greenautarky-setup"):
                configs.append(
                    StaticPathConfig(f"/{sub}/{file.name}", str(file), True)
                )
    return configs


# Stock HA panels that the GA tenant flow does not surface in the sidebar.
# Listed by panel name (= frontend route segment, i.e. what appears after
# the slash). If HA Core renames one of these in a future release, the
# renamed panel simply never matches — the others continue to work. A rename
# is therefore SILENT; the thing that would catch it is the e2e assertion in
# ha-operating-system (tests/e2e/tests/resident-sidebar.spec.ts), which asks
# the running device what a resident's sidebar holds instead of asking this
# list what it declares.
#
# The list is conservative — we keep:
#   - "lovelace"          (Übersicht — primary GA dashboard)
#   - "config"            (Einstellungen — admin-only, already gated)
#   - "developer-tools"   (Entwicklerwerkzeuge — admin-only, already gated)
#   - "profile"           (User profile)
#   - panel_custom        (anything our custom_components register)
#
# Drop:
#   - "energy"            (energy dashboard — GA has its own analytics)
#   - "logbook"           (Verlauf log)
#   - "history"           (Verlauf graphs)
#   - "media-browser"     (Medien)
#   - "todo"              (To-do-Listen)
#   - "map"               (Karte — not relevant for indoor iHost devices)
GA_HIDDEN_DEFAULT_PANELS: tuple[str, ...] = (
    "energy",
    "logbook",
    "history",
    "media-browser",
    "todo",
    "map",
)


def _hide_default_ha_panels(hass: HomeAssistant) -> None:
    """Keep HA's stock sidebar panels out of the GA tenant flow.

    This is an INVARIANT, not a sweep with a schedule.

    History, because the shape of the bug is the whole point. The first
    version removed the panels once, inside setup. ``todo`` survived, so a
    second run was added on ``EVENT_HOMEASSISTANT_STARTED`` and the docstring
    named ``todo`` as the reason. Measured on a canary on 2026-09-15, four of
    the six were gone and ``map`` and ``todo`` — the two the second run had
    been written for — were still in the resident's sidebar.

    Neither startup ordering nor a Core rename explains that. Both panels are
    registered by HOME ASSISTANT'S OWN ONBOARDING COMPLETION, which on a GA
    device happens while the resident walks through OUR wizard, minutes to
    hours after the last sweep:

      * ``POST /api/onboarding/core_config`` creates a ``shopping_list``
        config entry (Core's ``onboarding/views.py``, ``onboard_integrations``).
        Setting it up forwards the ``todo`` platform, and ``todo.async_setup``
        calls ``frontend.async_register_built_in_panel(hass, "todo", …)``.
      * ``lovelace.async_setup`` registers ``create_map_dashboard`` as an
        onboarding listener while the instance is not onboarded. Completing
        onboarding fires it; the ``map`` dashboard lands in the dashboards
        collection and its listener registers the ``map`` panel.

    The four that DID disappear (``energy``, ``logbook``, ``history``,
    ``media-browser``) arrive via ``default_config`` at boot — which is why the
    first run caught them and the defect looked like "two panels are special".

    So the defect class is a ONE-SHOT MUTATION of a registry other integrations
    keep writing to. Any fixed number of runs loses the same race at the next
    registration. What holds is subscribing to the registry's own change signal
    — ``EVENT_PANELS_UPDATED``, which ``async_register_built_in_panel`` and
    ``async_remove_panel`` both fire — and re-establishing the invariant
    whenever the registry changes. That is edge-triggered on the exact mutation,
    not a timer polling for one.

    Two details that are load-bearing:

    * The membership check before ``async_remove_panel`` is not an
      optimisation. ``async_remove_panel`` logs ``Removing unknown panel <x>``
      at WARNING for every name it does not find, so calling it unconditionally
      on every registry change would print six warnings per panel registration
      on a live device.
    * Termination: removing a panel fires ``EVENT_PANELS_UPDATED`` again, which
      re-enters this listener, which finds nothing left to remove and fires
      nothing. Bounded at one extra pass; a registration we do not care about
      removes nothing and so fires nothing at all.
    """

    @callback
    def _remove_present() -> int:
        """Remove every listed panel that is currently registered."""
        panels = hass.data.get(frontend.DATA_PANELS) or {}
        removed = 0
        for panel in GA_HIDDEN_DEFAULT_PANELS:
            if panel not in panels:
                continue
            try:
                frontend.async_remove_panel(hass, panel)
            except Exception as e:
                # Don't let a single rename/refactor in HA Core take down setup.
                _LOGGER.warning("failed to remove panel %s: %s", panel, e)
            else:
                removed += 1
                _LOGGER.debug("removed default HA panel: %s", panel)
        return removed

    _remove_present()

    @callback
    def _on_panels_updated(_event: Event) -> None:
        _remove_present()

    # Replaces any listener from a previous setup of this component so a
    # reload cannot leave two of them attached.
    _detach_panel_sweep(hass)
    hass.data[DATA_PANEL_SWEEP_UNSUB] = hass.bus.async_listen(
        EVENT_PANELS_UPDATED, _on_panels_updated
    )


@callback
def _detach_panel_sweep(hass: HomeAssistant) -> None:
    """Stop maintaining the stock-panel invariant (unload / re-setup)."""
    unsub = hass.data.pop(DATA_PANEL_SWEEP_UNSUB, None)
    if unsub is not None:
        unsub()


async def _async_register_panel(hass: HomeAssistant) -> None:
    """Register the panel so the wizard is accessible from the HA app."""
    panel_dir = Path(__file__).parent / "panel" / "dist"

    await hass.http.async_register_static_paths(
        [StaticPathConfig(URL_BASE, str(panel_dir), cache_headers=False)]
    )

    await panel_custom.async_register_panel(
        hass=hass,
        frontend_url_path=PANEL_URL_PATH,
        webcomponent_name="ga-onboarding-panel",
        sidebar_title="Einrichtung",
        sidebar_icon="mdi:rocket-launch",
        module_url=f"{URL_BASE}/entrypoint.js",
        embed_iframe=False,
        require_admin=False,
    )


_WIZARD_SETUP_PATH = "/greenautarky-setup.html"

# The device label's QR code encodes
#   http://<prefix>.ki-butler.greenautarky.com/?pin=<pin>&device=<id>
# and the setup panel reads exactly these two back out of `window.location`
# (ha-panel-greenautarky-setup.ts): `pin` auto-fills the six digits, `device`
# names the unit, and the panel then clears both from the address bar.
# Redirecting `/` to a bare path throws them away, so a customer who scanned
# the QR code still has to read the PIN off the label and type it in — which
# is the one thing the QR code exists to avoid.
#
# An ALLOWLIST, not the whole query string: these are the only two the
# consumer reads, and nothing else customer-controlled belongs in a Location
# header. Re-encoding through urlencode() also normalises whatever arrived.
_WIZARD_FORWARDED_PARAMS = ("pin", "device")


def _wizard_redirect_target(request: web.Request) -> str:
    """`/greenautarky-setup.html`, carrying the label's pin/device through."""
    query = getattr(request, "query", None) or {}
    forwarded = [(k, query[k]) for k in _WIZARD_FORWARDED_PARAMS if query.get(k)]
    if not forwarded:
        return _WIZARD_SETUP_PATH
    return f"{_WIZARD_SETUP_PATH}?{urlencode(forwarded)}"


def _patch_index_view_for_wizard_redirect(hass: HomeAssistant) -> None:
    """Monkey-patch HA's IndexView.get to redirect `/` → /greenautarky-setup.html
    while the GA wizard is incomplete.

    Why we have to monkey-patch instead of registering our own `/` view:
    `frontend` is a hard dependency of this integration, so by the time
    we call `_async_setup_common` the frontend integration has already
    registered IndexView at `/` and aiohttp resolves that route first.

    Why the existing `add_extra_js_url`-based redirect isn't enough:
    HA Core injects extra_module_url tags ONLY into the authenticated
    dashboard HTML (see homeassistant.components.frontend.IndexView.get).
    On a fresh device the first hit lands on `/onboarding.html` or
    `/auth/authorize` — neither carries our redirect script, so the
    customer never lands on the GA wizard automatically. Confirmed
    live on KIB-SON-00000000 bench on BOSv1.2.0 build #6.

    Behavior of the patch:
    - GA wizard incomplete → 302 to /greenautarky-setup.html
    - GA wizard complete → fall through to HA's original IndexView.get
      (which then handles HA-stock onboarding state + dashboard
       authentication as usual)

    Idempotent: marks `IndexView._ga_wizard_patched = True` on the
    class object so re-entry (e.g. an integration reload) doesn't
    re-wrap the already-wrapped method.

    Fleet safety:
    - Already-deployed devices that completed the wizard before this
      code shipped have `completed=True` in storage → patch is a no-op
      (falls through to original IndexView.get).
    - Old devices that never had a stored onboarding state have
      `completed=True` written by default in `_async_setup_common`
      (see the `state is None` branch) → also no-op.
    - The only behavioural change is on devices with
      `completed=False` in storage — which is precisely the "wizard
      pending" state where we WANT the redirect.
    """
    from functools import wraps

    from homeassistant.components.frontend import IndexView

    if getattr(IndexView, "_ga_wizard_patched", False):
        return

    original_get = IndexView.get

    @wraps(original_get)
    async def patched_get(self, request: web.Request) -> web.Response:
        state = _get_state(hass) or {}
        if not state.get("completed", False):
            return web.Response(
                status=302,
                headers={"location": _wizard_redirect_target(request)},
            )
        return await original_get(self, request)

    IndexView.get = patched_get  # type: ignore[method-assign]
    IndexView._ga_wizard_patched = True  # type: ignore[attr-defined]

    # Patching the CLASS is not enough, and getting this wrong is silent.
    #
    # IndexView._route is a `cached_property` returning
    # `ResourceRoute("GET", self.get, self)`. It evaluates `self.get` at FIRST
    # ACCESS and caches the finished ResourceRoute in the instance __dict__.
    # `resolve()` touches `self._route` on every request that reaches the
    # resource, so ANY earlier hit — a monitoring probe, the fleet-manager
    # poll, a browser, HA's own startup traffic — materialises it before a
    # custom_component has finished setting up. The cached route then holds a
    # bound method of the ORIGINAL function forever, and re-assigning the class
    # attribute afterwards changes nothing: no error, no log line, the redirect
    # simply never fires.
    #
    # Seen in the field: with the wizard unfinished and the setup page serving
    # normally, `/` still answered 200 with Home Assistant's own frontend. The
    # QR code on the device label points at `/`, so a customer scanning it
    # landed in Home Assistant with no account. The same unit had behaved
    # correctly on an earlier boot — which is what a race that is lost or won
    # at startup looks like, and why hand-testing calls it fixed.
    #
    # Dropping the cached value makes the next access rebuild the route against
    # the patched function. Correct whether we arrive early (nothing cached yet)
    # or late (stale route discarded).
    rebuilt = 0
    try:
        for resource in hass.http.app.router.resources():
            if isinstance(resource, IndexView):
                if resource.__dict__.pop("_route", None) is not None:
                    rebuilt += 1
    except Exception:  # pragma: no cover - never break setup over this
        _LOGGER.exception(
            "greenautarky_site: could not drop the cached IndexView route; the "
            "`/` → wizard redirect may not fire"
        )

    _LOGGER.info(
        "greenautarky_site: patched IndexView.get to redirect `/` → "
        "/greenautarky-setup.html while wizard is incomplete (server-side, "
        "fires before any HA JS bundle loads); dropped %s stale cached route(s)",
        rebuilt,
    )


def _register_redirect_js(hass: HomeAssistant) -> None:
    """Inject the `/` → wizard redirect as a client-side JS module.

    Replaces the IndexView patch from the GA HA Core fork. The aiohttp
    middleware approach (v0.1.x) does not work from a custom_component —
    the middleware list is frozen by the time we set up (Finding 20).

    `frontend.add_extra_js_url` is the blessed API for custom integrations
    to inject JS into the HA frontend. The module (`ga-onboarding-redirect.js`,
    served as a static path by `_async_register_frontend_bundle`) checks the
    onboarding status and redirects the browser to /greenautarky-setup.html
    while onboarding is incomplete.

    Trade-off vs. the server-side patch: the HA frontend bundle begins
    loading before the redirect fires, so there is a brief flash of the
    HA UI. Acceptable for a one-time onboarding flow.

    Defensive: `add_extra_js_url` indexes `hass.data["frontend_extra_module_url"]`,
    which only exists once the `frontend` component has set up. On a real
    device `frontend` is always present, but in minimal HA setups / unit
    tests it may not be — so a KeyError here is non-fatal: the wizard
    stays reachable directly at /greenautarky-setup.html.
    """
    try:
        add_extra_js_url(hass, REDIRECT_JS_URL)
    except KeyError:
        _LOGGER.warning(
            "frontend component not available — onboarding redirect JS not "
            "injected; wizard still reachable directly at /greenautarky-setup.html"
        )
        return
    _LOGGER.debug("Registered onboarding redirect JS module at %s", REDIRECT_JS_URL)
