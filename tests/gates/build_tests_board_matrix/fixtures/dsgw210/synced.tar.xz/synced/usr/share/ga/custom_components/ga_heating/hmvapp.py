"""What the decision engine (hmvapp) PROPOSES, applied through ga_heating's own guards.

Principle (Thomas, 2026-09-25): ga_heating is the ONLY writer to the valves. hmvapp
publishes desired values over MQTT; ga_heating consumes them. No parallel paths.

Three interfaces, all read from the MQTT-discovery sensors hmvapp publishes (retained):

=====================  ===========================================  =====================
what                   sensor / topic                               option (env), default
=====================  ===========================================  =====================
calibration offset     ``sensor.hm_<ieee>_desired_offset``          always on (contract 1,
                       (see calibration.py)                         falls back to physics)
valve opening degree   ``sensor.hm_<ieee>_desired_opening_degree``  ``GA_HEATING_APPLY_
                       ← ``ga/hm/valves/<ieee>/desired_opening_      OPENING_DEGREE``, OFF
                       degree``
room mode              any ``sensor.hm_*_desired_mode`` whose       ``GA_HEATING_APPLY_
                       ``room`` attribute is the room entity        MODE_REQUESTS``, OFF
                       ← ``ga/hm/rooms/<room_key>/desired_mode``
=====================  ===========================================  =====================

Contract 2 (opening + mode): attributes ``contract`` (major 2), ``reason``,
``valid_until`` (ISO-8601, UTC), ``room``, ``decided_at``, ``model_version``. Anything
expired, unparseable, of another contract or out of range is ignored — never written —
and said once. An option that is off ignores even a valid request, and says so once.

The options follow the component's only existing convention (``GA_HEATING_MANUAL_CAP_
HOURS``): an environment variable of Home Assistant Core, truthy = 1/true/yes/on.
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any

from homeassistant.components.climate import HVACMode
from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from . import DOMAIN, _manual_until, _own_context, _save, start_manual_period
from .calibration import _warn_once

if TYPE_CHECKING:
    from .climate import GARoomClimate

_LOGGER = logging.getLogger(__name__)

CONTRACT_MAJOR = 2
OPENING_OPTION = "GA_HEATING_APPLY_OPENING_DEGREE"
MODE_OPTION = "GA_HEATING_APPLY_MODE_REQUESTS"
REQUEST_PREFIX = "sensor.hm_"
OPENING_SUFFIX = "_desired_opening_degree"
OPENING_NUMBER_SUFFIX = "_valve_opening_degree"
MODE_SUFFIX = "_desired_mode"
MODES = (HVACMode.AUTO, HVACMode.HEAT, HVACMode.OFF)
#: An opening we sent and the valve has not reported back yet is not re-sent sooner.
OPENING_RESEND_AFTER = timedelta(minutes=10)


def option_enabled(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def _data(hass: HomeAssistant, key: str) -> dict[str, Any]:
    return hass.data.setdefault(DOMAIN, {}).setdefault(key, {})


def _valid(hass: HomeAssistant, entity: str, state: Any, now: datetime) -> bool:
    """Contract 2 envelope: right major, parseable and unexpired `valid_until`."""
    attrs = state.attributes
    try:
        major = int(str(attrs.get("contract", "")).split(".")[0])
    except ValueError:
        major = -1
    if major != CONTRACT_MAJOR:
        _warn_once(hass, f"{entity}:contract:{attrs.get('contract')}",
                   "ga_heating: %s carries contract %r, this component speaks %d for "
                   "it — ignored", entity, attrs.get("contract"), CONTRACT_MAJOR)
        return False
    valid_until = dt_util.parse_datetime(str(attrs.get("valid_until", "")))
    if valid_until is None:
        _warn_once(hass, f"{entity}:valid_until:{attrs.get('valid_until')}",
                   "ga_heating: %s has no parseable valid_until (%r) — ignored",
                   entity, attrs.get("valid_until"))
        return False
    if valid_until.tzinfo is None:
        valid_until = valid_until.replace(tzinfo=dt_util.UTC)
    if valid_until <= now:
        _warn_once(hass, f"{entity}:expired:{attrs.get('valid_until')}",
                   "ga_heating: %s expired at %s — ignored, nothing is written",
                   entity, valid_until.isoformat())
        return False
    return True


# ── D: valve opening degree ───────────────────────────────────────────────────

def read_opening(hass: HomeAssistant, valve: str, now: datetime) -> int | None:
    ieee = valve.removeprefix("climate.")
    entity = f"{REQUEST_PREFIX}{ieee}{OPENING_SUFFIX}"
    state = hass.states.get(entity)
    if state is None or state.state in ("unavailable", "unknown", ""):
        return None
    if not _valid(hass, entity, state, now):
        return None
    try:
        raw = float(state.state)
    except ValueError:
        raw = None
    if raw is None or not raw.is_integer() or not 0 <= raw <= 100:
        _warn_once(hass, f"{entity}:value:{state.state}",
                   "ga_heating: %s = %r is not an opening degree 0-100 — ignored",
                   entity, state.state)
        return None
    return int(raw)


async def _apply_opening(
    hass: HomeAssistant, room: GARoomClimate, valve: str, now: datetime
) -> bool:
    desired = read_opening(hass, valve, now)
    if desired is None:
        return False
    if not option_enabled(OPENING_OPTION):
        _warn_once(hass, f"{valve}:opening:option_off",
                   "ga_heating: hmvapp proposes an opening degree for %s; not applied "
                   "because %s is off", valve, OPENING_OPTION)
        return False
    if room.hvac_mode == HVACMode.OFF:
        return False  # a room the resident switched off is not reopened by the engine
    number = f"number.{valve.removeprefix('climate.')}{OPENING_NUMBER_SUFFIX}"
    current = hass.states.get(number)
    if current is None or current.state in ("unavailable", "unknown"):
        return False
    try:
        if int(float(current.state)) == desired:
            return False
    except ValueError:
        pass
    last = _data(hass, "opening_written").get(valve)
    if last and last["value"] == desired and now - last["at"] < OPENING_RESEND_AFTER:
        return False
    await hass.services.async_call(
        "number", "set_value", {"entity_id": number, "value": desired},
        blocking=True, context=_own_context(hass),
    )
    _data(hass, "opening_written")[valve] = {"value": desired, "at": now}
    _LOGGER.info("ga_heating: %s opening degree %s → %s (hmvapp)",
                 valve, current.state, desired)
    return True


# ── E: room mode ──────────────────────────────────────────────────────────────

def _mode_requests(hass: HomeAssistant, room_entity: str) -> list[Any]:
    return [
        s for s in hass.states.async_all("sensor")
        if s.entity_id.startswith(REQUEST_PREFIX)
        and s.entity_id.endswith(MODE_SUFFIX)
        and s.attributes.get("room") == room_entity
    ]


async def _apply_mode(hass: HomeAssistant, room: GARoomClimate, now: datetime) -> bool:
    """One room: apply a valid mode request once, through the room's own path.

    DECISIONS (2026-09-25):
    * Applied ONCE per request (state + decided_at), not every tick. A resident who
      answers the engine — e.g. sets `auto` after the engine asked for `heat` — is not
      overruled by the same request a minute later. A NEW decision may.
    * Overrides (boost, window, absence) outrank it; the request waits and applies
      when the override ends, if still valid. A resident's running manual period
      outranks it too.
    * An engine `heat` is capped like any manual heat (`GA_HEATING_MANUAL_CAP_HOURS`,
      3 h), started at once and visible in `manual_until`. The cap exists against a
      forgotten heat, and an engine that stops publishing forgets too. After the cap
      the room returns to `auto`; the same request is not re-applied.
    * `off` has no cap: it ends with the engine's next request or the resident.
    """
    applied = _data(hass, "mode_applied")
    engine_manual = _data(hass, "mode_engine_manual")
    for state in _mode_requests(hass, room.entity_id):
        entity = state.entity_id
        if state.state in ("unavailable", "unknown", ""):
            continue
        if not _valid(hass, entity, state, now):
            continue
        if state.state not in MODES:
            _warn_once(hass, f"{entity}:value:{state.state}",
                       "ga_heating: %s = %r is not auto|heat|off — ignored",
                       entity, state.state)
            continue
        stamp = state.attributes.get("decided_at") or state.attributes.get("valid_until")
        key = f"{state.state}|{stamp}"
        if applied.get(room.entity_id) == key:
            continue
        if not option_enabled(MODE_OPTION):
            _warn_once(hass, f"{entity}:option_off",
                       "ga_heating: %s asks %s for %s; not applied because %s is off",
                       entity, room.entity_id, state.state, MODE_OPTION)
            continue
        if room._override_active():
            continue  # boost / window / absence outrank the engine; retried next tick
        if not _manual_until(hass).get(room.entity_id):
            engine_manual.pop(room.entity_id, None)
        elif not engine_manual.get(room.entity_id):
            continue  # the resident's manual period outranks the engine
        applied[room.entity_id] = key
        requested = HVACMode(state.state)
        if room.hvac_mode == requested:
            return False
        await hass.services.async_call(
            "climate", "set_hvac_mode",
            {"entity_id": room.entity_id, "hvac_mode": requested},
            blocking=True, context=_own_context(hass),
        )
        if requested == HVACMode.HEAT:
            start_manual_period(hass, room.entity_id, datetime.now())
            engine_manual[room.entity_id] = True
            await _save(hass)
            room.async_write_ha_state()
        else:
            engine_manual.pop(room.entity_id, None)
        _LOGGER.info("ga_heating: %s → %s (hmvapp: %s)", room.entity_id, requested,
                     state.attributes.get("reason", "unspecified"))
        return True
    return False


async def async_apply_hmvapp_requests(hass: HomeAssistant, now: datetime | None = None) -> int:
    """One pass from the minute tick. Returns the number of writes/mode changes."""
    now = now if now is not None else dt_util.utcnow()
    if now.tzinfo is None:
        now = now.replace(tzinfo=dt_util.UTC)
    done = 0
    rooms: dict[str, GARoomClimate] = hass.data.get(DOMAIN, {}).get("room_entities") or {}
    for room in list(rooms.values()):
        try:
            if await _apply_mode(hass, room, now):
                done += 1
        except Exception as err:  # one room must not stop the others
            _LOGGER.warning("ga_heating: mode request for %s failed: %r",
                            room.entity_id, err)
        for valve in room.valves:
            try:
                if await _apply_opening(hass, room, valve, now):
                    done += 1
            except Exception as err:
                _LOGGER.warning("ga_heating: opening degree for %s failed: %r", valve, err)
    return done
