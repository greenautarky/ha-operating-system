"""Device sync: hand the plan to the thermostat, and notice when it does not take it.

Two thermostats, two worlds:

* **A thermostat that can hold a weekly plan** should hold OURS. Then it heats on its
  own — through a reboot, an OTA, a power cut on our box. Home Assistant is not in the
  loop at all. This is the better world, and we want it whenever the hardware allows.
* **A thermostat that cannot** is driven by the executor in Core, one setpoint at a
  time. Works everywhere; needs us to be alive.

They must never both be active. A setpoint write kicks a TRV out of `auto` back into
manual — proven on K0: we mirrored a plan, switched the device to `auto`, and our own
executor promptly knocked it back to `heat` at the next transition. So exactly one of
the two owns a given thermostat, and `mode_for()` decides which.

## Noticing failure

The hard part is not writing the plan — it is finding out that the device ignored it.

`text.set_value` returns as soon as Zigbee2MQTT *has* the value; if the device then
refuses it, the error goes to the Z2M log and nowhere else. The first version of this
code cheerfully reported "7 days mirrored" while the thermostat rejected all seven.

So we listen where the truth actually is: Z2M publishes its log to
`zigbee2mqtt/bridge/logging`. An error naming our device is a rejection, and it is
recorded against that thermostat and logged loudly. On top of that, `verify_setpoint()`
checks the device's *behaviour* at a slot transition — the only proof that survives a
lying cache: if the plan says 19.5 °C and the thermostat sits at 16 °C ten minutes into
the slot, it is not running our plan, whatever anyone claims.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from homeassistant.core import HomeAssistant

_LOGGER = logging.getLogger(__name__)

Z2M_LOG_TOPIC = "zigbee2mqtt/bridge/logging"

# How far the thermostat may sit from the plan before we call it a mismatch. Half a
# degree: TRVs round, and we would rather miss a small drift than cry wolf.
SETPOINT_TOLERANCE = 0.6

MODE_DEVICE = "device"  # the thermostat runs the plan itself
MODE_CORE = "core"  # we push setpoints
MODE_MANUAL = "manual"  # the resident owns the dial; the plan stays out of it
MODE_OFF = "off"


def mode_for(state: Any, has_device_schedule: bool) -> str:
    """Who owns this thermostat right now?

    The device's own modes carry the meaning, and the UI has always said so out loud:
    KI = ``auto`` (the plan runs), MANUEL = ``heat`` (you set it yourself), AUS = ``off``.

    A thermostat with no ``auto`` mode has no way to express "follow the plan" — for
    those, any heating mode means the plan is on, because otherwise the plan could never
    run at all.
    """
    if state is None:
        return MODE_OFF
    hvac = state.state
    if hvac in ("off", "unavailable", "unknown"):
        return MODE_OFF

    modes = state.attributes.get("hvac_modes") or []
    if "auto" not in modes:
        return MODE_CORE  # no way to say "auto" → we are the schedule

    if hvac != "auto":
        return MODE_MANUAL  # the resident chose manual, and that is a real choice

    return MODE_DEVICE if has_device_schedule else MODE_CORE


def verify_setpoint(state: Any, expected: float) -> tuple[bool, str]:
    """Is the thermostat actually running the plan? ``(ok, detail)``.

    This is the only check that cannot be fooled by a stale cache or an optimistic
    service call: it looks at what the radiator is being told to do.
    """
    current = state.attributes.get("temperature") if state else None
    if current is None:
        return False, "the thermostat reports no setpoint"
    if abs(float(current) - expected) <= SETPOINT_TOLERANCE:
        return True, ""
    return False, f"plan says {expected} °C, thermostat sits at {current} °C"


# A z2m error naming our thermostat is not automatically a refusal of our plan. It is
# one only if the device is talking about the SCHEDULE it was given. Measured on K0
# (2026-08-17): a malformed read we issued ourselves produced "No converter available
# for 'weekly_schedule' on '0x0cae…'", and the watcher reported a refusal and wrote
# ok=False into the status the resident's card reads. Nothing had been refused.
#
# So: the message must both name the device AND carry the device's own verdict on the
# schedule. Nothing else discriminates. In particular do NOT filter on "publish" or
# "failed" — a genuine refusal arrives wrapped in exactly that:
#
#   Publish 'set' 'weekly_schedule_wednesday' to '0x…' failed:
#     'Error: Invalid schedule for wednesday: the first transition of each day
#      should start at 00:00'
#
# An earlier attempt at this fix excluded those words and would have suppressed the one
# signal the watcher exists for. The test built from that real device message is what
# caught it — which is the argument for keeping fixtures made of measured wording
# rather than imagined wording.
_REJECTION_MARKERS = ("invalid schedule", "schedule for", "transition")

# Transport verdicts: Zigbee2MQTT could not get the frame to the device, or gave up
# waiting. The device said nothing, so nothing was refused. Measured on K31
# (BOSv1.3.0-rc55, 2026-09-28): after a z2m restore the valves were off the network for
# ~6 minutes and every mirrored day came back as
#
#   Publish 'set' 'weekly_schedule_wednesday' to '0x…' failed: 'Error: ZCL command
#     0x…/1 hvacThermostat.setWeeklySchedule({"dayofweek":8, … "transitions":[…]},
#     {…}) failed (Delivery failed for '48527'.)'
#
# Until 0.11.2 the marker "transition" matched inside the ECHOED ARGUMENT and this was
# recorded as a refusal — which then kept four valves out of `auto` for good.
_TRANSPORT_MARKERS = ("delivery failed", "timeout", "request superseded")


def _strip_echoed_arguments(message: str) -> str:
    """The message without the arguments Z2M echoes back from OUR command.

    Z2M repeats the ZCL call it attempted — ``setWeeklySchedule({...}, {...})`` — and
    that echo is our own payload, not the device's verdict. Every balanced ``(…)``
    group that contains a ``{`` is dropped; the verdict — ``failed (Delivery failed
    for '48527'.)``, ``Error: Invalid schedule for wednesday: …`` — carries no braces
    and survives.
    """
    out: list[str] = []
    i = 0
    while i < len(message):
        if message[i] == "(":
            depth, j = 0, i
            while j < len(message):
                if message[j] == "(":
                    depth += 1
                elif message[j] == ")":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            group = message[i:j + 1]
            if depth == 0 and "{" in group:
                i = j + 1
                continue
        out.append(message[i])
        i += 1
    return "".join(out)


def _verdict(message: str) -> str:
    return _strip_echoed_arguments(message).lower()


def _is_transport(message: str) -> bool:
    """Z2M could not reach the device — no verdict from it at all."""
    low = _verdict(message)
    return any(m in low for m in _TRANSPORT_MARKERS)


def _is_rejection(message: str) -> bool:
    """Does the DEVICE say the schedule was refused?

    Classifies the verdict, never the payload: the echoed command arguments are cut
    first (`_strip_echoed_arguments`). What is left of a transport failure — "failed
    (Delivery failed for '…'.)" — carries none of the markers, so no transport denylist
    is needed here (and a denylist is dangerous, see above). Do NOT filter on "publish"
    or "failed": a genuine refusal arrives wrapped in exactly those. The two fixture
    sets in tests/fixtures/z2m_log hold both sides; one of them only passes because the
    echo is cut.
    """
    low = _verdict(message)
    return any(m in low for m in _REJECTION_MARKERS)


def _error_naming(payload: str, device_name: str) -> str | None:
    """The message of a Z2M error-level log entry naming ``device_name``, or None."""
    try:
        entry = json.loads(payload)
    except (ValueError, TypeError):
        return None
    if not isinstance(entry, dict) or entry.get("level") != "error":
        return None
    message = str(entry.get("message") or "")
    if device_name not in message:
        return None
    return message


def parse_z2m_error(payload: str, device_name: str) -> str | None:
    """A Zigbee2MQTT log line that means "your schedule was refused", or None.

    Z2M is explicit when it refuses, e.g.::

        Invalid schedule for wednesday: the first transition of each day should start
        at 00:00

    We keep the message verbatim: it is the device telling us its rules, and it is worth
    more in a log than any wording of ours.
    """
    message = _error_naming(payload, device_name)
    if message is None or not _is_rejection(message):
        return None
    return message


def parse_z2m_undelivered(payload: str, device_name: str) -> str | None:
    """A Zigbee2MQTT log line that means "your schedule never reached the device".

    A write of a ``weekly_schedule_*`` that failed in transport. Not a refusal: the
    plan is simply not on the valve yet, and it is sent again when the valve is back
    (see `GARoomClimate._check_hand_on_valve`). Other writes that fail in transport
    (a setpoint, a mode) are not about the plan and are not reported here.
    """
    message = _error_naming(payload, device_name)
    if message is None or "weekly_schedule" not in message:
        return None
    if not _is_transport(message):
        return None
    return message


async def async_watch_z2m_errors(
    hass: HomeAssistant, on_error: Any
) -> Any | None:
    """Listen to Z2M's own log for rejections. Returns an unsubscribe callable.

    Degrades quietly: on a device without the MQTT integration there is nothing to
    listen to, and the executor still works — we just cannot tell a rejection from a
    success, which is exactly what the caller records.
    """
    try:
        from homeassistant.components import mqtt
    except ImportError:  # pragma: no cover - mqtt ships with HA
        return None

    try:
        return await mqtt.async_subscribe(
            hass, Z2M_LOG_TOPIC, lambda msg: on_error(msg.payload), qos=0
        )
    except Exception as err:
        _LOGGER.info(
            "ga_heating: cannot watch %s (%r) — a thermostat that refuses a plan will "
            "do so silently; the executor is unaffected",
            Z2M_LOG_TOPIC,
            err,
        )
        return None
