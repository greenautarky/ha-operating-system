package b

func B() string { return "b" }
