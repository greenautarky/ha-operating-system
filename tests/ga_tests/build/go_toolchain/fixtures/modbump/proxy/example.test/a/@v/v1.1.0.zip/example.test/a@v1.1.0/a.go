package a

func A() string { return "a1" }
