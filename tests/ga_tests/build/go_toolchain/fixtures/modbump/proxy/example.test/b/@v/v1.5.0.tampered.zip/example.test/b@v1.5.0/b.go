package b

func B() string { return "evil" }
