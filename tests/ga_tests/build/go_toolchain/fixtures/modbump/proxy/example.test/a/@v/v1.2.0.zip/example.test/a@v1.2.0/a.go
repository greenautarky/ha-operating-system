package a

import "example.test/b"

func A() string { return "a2" + b.B() }
